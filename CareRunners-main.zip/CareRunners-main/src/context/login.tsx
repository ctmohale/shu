import { createContext } from "react";

const LoginUser = createContext<any>({});
export default LoginUser;
