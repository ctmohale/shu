import { createContext } from "react";

const PickUprequest = createContext<any>({});
export default PickUprequest;
