import { createContext } from "react";

const MembershipMainData = createContext<any>({});
export default MembershipMainData;
