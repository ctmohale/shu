import { createContext } from "react";

const MembershipAccess = createContext<any>({});
export default MembershipAccess;
