import { createContext } from "react";

const FilesRecord = createContext<any>({});
export default FilesRecord;
