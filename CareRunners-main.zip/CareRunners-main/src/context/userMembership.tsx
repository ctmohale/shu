import { createContext } from "react";

const UserMembershipMainData = createContext<any>({});
export default UserMembershipMainData;
