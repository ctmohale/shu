import { createContext } from "react";

const AuthSetEmail = createContext<any>({});
export default AuthSetEmail;
