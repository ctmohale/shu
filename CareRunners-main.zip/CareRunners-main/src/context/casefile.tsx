import { createContext } from "react";

const CaseFile = createContext<any>({});
export default CaseFile;