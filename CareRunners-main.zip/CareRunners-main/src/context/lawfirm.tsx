import { createContext } from "react";

const LawFirm = createContext<any>({});
export default LawFirm;
