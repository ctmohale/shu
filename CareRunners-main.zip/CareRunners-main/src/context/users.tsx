import { createContext } from "react";

const Users = createContext<any>({});
export default Users;