import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonPage,
  IonRow,
  IonTitle,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { AiOutlineUser } from "react-icons/ai";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { GoLaw } from "react-icons/go";
import { useContext, useEffect, useState } from "react";
import Users from "../context/users";
import LoginUser from "../context/login";
import LawFirm from "../context/lawfirm";
import {
  UpdateLawFirmInput,
  UpdateLawFirmMutation,
  UpdateUserInput,
  UpdateUserMutation,
} from "../API";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { GraphQLQuery } from "@aws-amplify/api";
import Swal from "sweetalert2";
import { HashLoader } from "react-spinners";

const Profile: React.FC = () => {
  //Global var
  const { user, setUser }: any = useContext(Users);
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);

  //User profile
  const [name, setName]: any = useState("");
  const [surname, setSurname]: any = useState("");
  const [email, setEmail]: any = useState("");
  const [cell, setCell]: any = useState("");

  //Company var
  const [comapany_name, set_comapany_name]: any = useState();
  const [comapany_cell_no, set_comapany_cell_no]: any = useState();
  const [comapany_email, set_comapany_email]: any = useState();
  const [comapany_reg, set_comapany_reg]: any = useState();
  const [comapany_addess, set_comapany_address]: any = useState();
  const [comapany_postal_Code, set_comapany_postal_Code]: any = useState();
  const [comapany_id, set_comapany_id]: any = useState("");
  const [isLoading, setIsloading]: any = useState(true);

  //Sweet Alert Toast
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  //Set user
  useEffect(() => {
    if (loginUser) {
      setName(loginUser.name);
      setSurname(loginUser.surname);
      setCell(loginUser.cell_no);
      setEmail(loginUser.email);
    }
  }, [loginUser]);

  useEffect(() => {
    if (user.length > 0) {
      setIsloading(false);
    }
  }, [user]);

  //Set comapnay
  useEffect(() => {
    if (lawfirm && loginUser) {
      lawfirm.forEach((firm_element: any) => {
        if (firm_element.user_id === loginUser.id) {
          console.log(lawfirm);
          set_comapany_name(firm_element.company_name);
          set_comapany_address(firm_element.address);
          set_comapany_cell_no(firm_element.cell_no);
          set_comapany_email(firm_element.comapany_email);
          set_comapany_reg(firm_element.comapany_reg);
          set_comapany_postal_Code(firm_element.postal_code);
          set_comapany_id(firm_element.id);
        }
      });
    }
  }, [lawfirm, loginUser]);

  //update profile function
  async function updateProfile(User_Id: any, Companay_id: any) {
    //User info
    const userDetails: UpdateUserInput = {
      id: User_Id,
      name: name,
      surname: surname,
      cell_no: cell,
    };

    //Comapany details
    const companayDetails: UpdateLawFirmInput = {
      id: Companay_id,
      company_name: comapany_name,
      company_registartion: comapany_reg,
      postal_code: comapany_postal_Code,
      company_email: comapany_email,
      address: comapany_addess,
      cell_no: comapany_cell_no,
    };

    //User
    const updateUserData = await API.graphql<GraphQLQuery<UpdateUserMutation>>({
      query: mutations.updateUser,
      variables: { input: userDetails },
    });

    //Company
    const updateCompanay = await API.graphql<
      GraphQLQuery<UpdateLawFirmMutation>
    >({
      query: mutations.updateLawFirm,
      variables: { input: companayDetails },
    });

    if (updateUserData && updateCompanay) {
      Toast.fire({
        icon: "success",
        title: "Profile updated successfully !.",
      });
    }
  }
  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />
        <br />
        <br />

        {isLoading ? (
          <HashLoader color="#36d7b7" />
        ) : (
          <IonGrid>
            <IonRow className="main_row">
              <IonCol className="globalCol mobile_hide" size="2">
                <IonCard className="globalCol main_card" routerLink="/profile">
                  <IonImg
                    className="globalCol card_img"
                    src="assets/undraw_profile_pic_ic5t.png"
                    alt=""
                  />
                  <div className="card_con">
                    <IonCardHeader className="globalCol">
                      <IonCardTitle className="card_title">
                        Account holder profile
                      </IonCardTitle>
                      <IonCardSubtitle className="card_title_sub">
                        {loginUser != "" ? (
                          <>
                            Profile :
                            {loginUser.name.substring(0, 1) +
                              " " +
                              loginUser.surname}
                          </>
                        ) : (
                          ""
                        )}
                      </IonCardSubtitle>
                    </IonCardHeader>
                  </div>
                </IonCard>
              </IonCol>

              {/* File upload section */}
              <IonCol>
                <IonCard className="main_card" style={{ padding: "5%" }}>
                  <IonTitle
                    className="title_mobile"
                    color="medium"
                    style={{ textAlign: "right" }}
                  >
                    <AiOutlineUser size="25" /> User profile
                  </IonTitle>
                  <br />
                  <br />
                  <IonItem>
                    <IonInput
                      color="medium"
                      label="Enter name"
                      labelPlacement="floating"
                      value={name}
                      onIonInput={(e: any) => setName(e.detail.value)}
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                  <IonItem>
                    <IonInput
                      color="medium"
                      label="Enter lastname"
                      value={surname}
                      onIonInput={(e: any) => setSurname(e.detail.value)}
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                  <IonItem>
                    <IonInput
                      color="medium"
                      label="Enter cell no"
                      value={cell}
                      onIonInput={(e: any) => setCell(e.detail.value)}
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                  <IonItem disabled>
                    <IonInput
                      label="Email account"
                      value={email}
                      onIonInput={(e: any) => setEmail(e.detail.value)}
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                  <IonItem disabled>
                    <IonInput
                      color="medium"
                      label="Password"
                      value="************"
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                </IonCard>
              </IonCol>

              <IonCol>
                <IonTitle
                  className="title_mobile"
                  color="medium"
                  style={{ textAlign: "right" }}
                >
                  <GoLaw /> Compnay profile
                </IonTitle>
                <hr />
                <IonItem>
                  <IonInput
                    label="*Company name"
                    onIonInput={(e: any) => set_comapany_name(e.detail.value)}
                    value={comapany_name}
                    labelPlacement="floating"
                    placeholder="Enter text"
                  ></IonInput>
                </IonItem>
                <IonItem>
                  <IonInput
                    label="*Company email"
                    onIonInput={(e: any) => set_comapany_email(e.detail.value)}
                    value={comapany_email}
                    labelPlacement="floating"
                    placeholder="Enter text"
                  ></IonInput>
                </IonItem>
                <IonItem>
                  <IonInput
                    color="medium"
                    label="*Address"
                    value={comapany_addess}
                    onIonInput={(e: any) =>
                      set_comapany_address(e.detail.value)
                    }
                    labelPlacement="floating"
                    placeholder="Enter text"
                  ></IonInput>
                </IonItem>
                <IonItem>
                  <IonInput
                    label="*Postal code:"
                    color="medium"
                    type="number"
                    value={comapany_postal_Code}
                    onIonInput={(e: any) =>
                      set_comapany_postal_Code(e.detail.value)
                    }
                    labelPlacement="floating"
                    placeholder="Enter text"
                  ></IonInput>
                </IonItem>

                <IonItem>
                  <IonInput
                    label="*Tell No:"
                    color="medium"
                    type="number"
                    value={comapany_cell_no}
                    onIonInput={(e: any) =>
                      set_comapany_cell_no(e.detail.value)
                    }
                    labelPlacement="floating"
                    placeholder="Enter text"
                  ></IonInput>
                </IonItem>

                <IonItem>
                  <IonInput
                    label="*Company registration:"
                    color="medium"
                    value={comapany_reg}
                    onIonInput={(e: any) => set_comapany_reg(e.detail.value)}
                    labelPlacement="floating"
                    placeholder="Enter text"
                  ></IonInput>
                </IonItem>

                <IonButton
                  shape="round"
                  fill="outline"
                  color="medium"
                  className="btn_up btn-request-update ion-margin"
                  onClick={() => updateProfile(loginUser.id, comapany_id)}
                >
                  <AiOutlineUser /> Update Profile
                </IonButton>
              </IonCol>
            </IonRow>
            <br />
            <br />
            <br />
          </IonGrid>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Profile;
