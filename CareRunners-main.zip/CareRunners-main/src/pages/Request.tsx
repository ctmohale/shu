import {
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonImg,
  IonInput,
  IonItem,
  IonItemDivider,
  IonLabel,
  IonModal,
  IonPage,
  IonRadio,
  IonRadioGroup,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import React, { useState, useRef, useEffect, useContext } from "react";
import { OverlayEventDetail } from "@ionic/core/components";
import { GraphQLSubscription } from "@aws-amplify/api";

import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { GraphQLQuery } from "@aws-amplify/api";

import "./Home.css";
import Nav from "../components/Nav";
import { AiFillEdit, AiOutlineCar, AiOutlineCloudUpload } from "react-icons/ai";
import { TfiLocationPin } from "react-icons/tfi";
import { FaCar } from "react-icons/fa";
import { IoArrowBackCircleSharp } from "react-icons/io5";
import { caretDownSharp } from "ionicons/icons";
import {
  CreatePickUpRequestInput,
  CreatePickUpRequestMutation,
  DeletePickUpRequestInput,
  DeletePickUpRequestMutation,
  OnDeletePickUpRequestSubscription,
} from "../API";
import Swal from "sweetalert2";
import PickUprequest from "../context/request";
import { AiFillCar } from "react-icons/ai";
import { MdDeleteSweep } from "react-icons/md";
import { TbEdit } from "react-icons/tb";
import RequestUpdate from "../components/RequestUpdate";
import * as subscriptions from "../graphql/subscriptions";
import { graphqlOperation } from "aws-amplify";
import { HashLoader } from "react-spinners";
import LawFirm from "../context/lawfirm";
import LoginUser from "../context/login";

function Request() {
  const modal = useRef<HTMLIonModalElement>(null);
  const input = useRef<HTMLIonInputElement>(null);
  const [requestType, setRequestType]: any = useState();
  const [requestDeliveryType, setRequestDeliveryType]: any = useState();
  const [destination, setDestination]: any = useState();
  const [resCell, setResCell]: any = useState();
  const [resFullName, setResFullName]: any = useState();
  const [desBool, setDestBool]: any = useState(false);
  const { pickRequest, setPickUprequest }: any = useContext(PickUprequest);
  const [urlData, setUrlData]: any = useState(false);
  const [isLoading, setIsloading]: any = useState(true);
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);
  const [comapany_id, set_comapany_id]: any = useState("");
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  //Google places API
  const [predictions, setPredictions]: any = useState([]);

  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  useEffect(() => {
    if (lawfirm && loginUser.id !== undefined) {
      lawfirm.forEach((element: any) => {
        if (element.user_id === loginUser.id) {
          set_comapany_id(element.id);
        }
      });
    }
  }, [lawfirm]);

  useEffect(() => {
    if (window.location.search.search("id")) {
      setUrlData(true);
    }
  }, []);

  useEffect(() => {
    if (pickRequest) {
      setIsloading(false);
    }
  }, [pickRequest]);

  //Delete request
  async function cancelDeleteRequest(id: any) {
    let requestPickUp: DeletePickUpRequestInput = {
      id: id,
    };
    const deleteRequest = await API.graphql<
      GraphQLQuery<DeletePickUpRequestMutation>
    >({
      query: mutations.deletePickUpRequest,
      variables: { input: requestPickUp },
    });

    if (deleteRequest.data) {
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener("mouseenter", Swal.stopTimer);
          toast.addEventListener("mouseleave", Swal.resumeTimer);
        },
      });

      Toast.fire({
        icon: "success",
        title: "Record deleted successfully!",
      });

      setInterval(() => {
        window.location.replace("/request");
      }, 1000);
    }
  }

  async function deleteConfirm(id: any) {
    const Toast = Swal.mixin({
      toast: true,
      position: "center",
      showConfirmButton: true,
      showCancelButton: true,
      confirmButtonColor: "rgba(216, 14, 0, 0.603)", // Set the button color to red
      customClass: {
        confirmButton: "custom-confirm-button",
        cancelButton: "custom-confirm-button",
      },
      timer: 10000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener("mouseenter", Swal.stopTimer);
        toast.addEventListener("mouseleave", Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: "error",
      title: "Are you sure you to delete record!",
    }).then((result) => {
      if (result.isConfirmed) {
        cancelDeleteRequest(id);
      }
    });
  }

  return (
    <IonPage>
      <IonContent>
        {/* Navigation section */}
        <Nav />
        <br />
        <br />

        <IonGrid>
          <IonRow className="main_row">
            <IonCol className="side_col_r" size="2">
              {/* Request ection */}
              <IonCard className="main_card">
                <IonImg
                  className="card_img"
                  src="assets/undraw_Note_list_re_r4u9_r.png"
                  alt=""
                />

                <div className="card_con">
                  <IonCardHeader>
                    <IonCardTitle className="card_title">
                      Request Pickup
                    </IonCardTitle>

                    <IonCardSubtitle className="card_title_sub">
                      <AiOutlineCar size="30" />
                    </IonCardSubtitle>
                  </IonCardHeader>
                </div>
              </IonCard>
            </IonCol>

            {/* File upload section */}

            {isLoading ? (
              <HashLoader color="#36d7b7" />
            ) : (
              <IonCol>
                <IonCard className="main_card" style={{ padding: "5%" }}>
                  <IonTitle
                    className="title_mobile"
                    color="medium"
                    style={{ textAlign: "right" }}
                  >
                    <AiOutlineCar size="25" /> Active Request
                    <IonItemDivider>
                      <IonLabel></IonLabel>
                    </IonItemDivider>
                  </IonTitle>
                  <hr />

                  {urlData ? (
                    <>
                      {/* Records requets */}
                      <IonGrid>
                        <IonRow className="file_lable">
                          <IonCol
                            className="mobile_hide"
                            size="1"
                            style={{ textAlign: "left" }}
                          >
                            ID
                          </IonCol>
                          <IonCol style={{ textAlign: "left" }}>
                            Request Type
                          </IonCol>
                          <IonCol
                            className="mobile_hide"
                            size="4"
                            style={{ textAlign: "left" }}
                          >
                            Destination
                          </IonCol>
                          <IonCol style={{ textAlign: "left" }}>
                            Request status
                          </IonCol>
                          <IonCol className="col">Open</IonCol>
                          <IonCol className="col mobile_hide">
                            Cancel request
                          </IonCol>
                        </IonRow>
                        {pickRequest != null ? (
                          <>
                            {pickRequest.map((request_elemen: any, id: any) => {
                              if (comapany_id === request_elemen.law_firm_id) {
                                return (
                                  <IonRow
                                    key={request_elemen.id}
                                    className="file_lable_sub"
                                    style={{
                                      background:
                                        request_elemen.request_status ===
                                        "Accepted"
                                          ? "rgba(2, 124, 133, 0.267)"
                                          : request_elemen.request_status ===
                                            "Completed"
                                          ? "rgba(2, 133, 41, 0.596)"
                                          : "",
                                    }}
                                  >
                                    <IonCol
                                      className="mobile_hide"
                                      size="1"
                                      style={{ textAlign: "left" }}
                                    >
                                      {id + 1}
                                    </IonCol>
                                    <IonCol style={{ textAlign: "left" }}>
                                      {request_elemen.request_type}
                                    </IonCol>
                                    <IonCol
                                      className="mobile_hide"
                                      size="4"
                                      style={{ textAlign: "left" }}
                                    >
                                      <TfiLocationPin />
                                      {request_elemen.destination_address}
                                    </IonCol>
                                    <IonCol style={{ textAlign: "left" }}>
                                      {request_elemen.request_status}
                                    </IonCol>
                                    <IonCol className="col">
                                      <IonButton
                                        shape="round"
                                        routerLink={
                                          "/update?id=" + request_elemen.id
                                        }
                                        className="btnUpdate"
                                      >
                                        <TbEdit /> Access
                                      </IonButton>
                                    </IonCol>
                                    <IonCol className="col mobile_hide">
                                      <IonButton
                                        shape="round"
                                        onClick={() =>
                                          deleteConfirm(request_elemen.id)
                                        }
                                        className="btnDelete"
                                      >
                                        <MdDeleteSweep /> Cancel
                                      </IonButton>
                                    </IonCol>
                                  </IonRow>
                                );
                              }
                            })}
                          </>
                        ) : (
                          ""
                        )}
                        <IonRow className="file_lable_botom"></IonRow>
                      </IonGrid>
                    </>
                  ) : (
                    <>
                      {/* Request  update*/}
                      <RequestUpdate />
                    </>
                  )}
                </IonCard>
              </IonCol>
            )}
          </IonRow>
          <br />
          <br /> <br />
          <br /> <br />
          <br />
        </IonGrid>
      </IonContent>
    </IonPage>
  );
}

export default Request;
