import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonPage,
  IonRow,
  IonTitle,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { BsFillCloudUploadFill } from "react-icons/bs";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { useState, useContext, useEffect } from "react";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { CreateCaseFileInput, CreateCaseFileMutation } from "../API";
import { GraphQLQuery } from "@aws-amplify/api";
import Swal from "sweetalert2";
import { text } from "ionicons/icons";
import { Amplify, Storage } from "aws-amplify";
import FilesRecord from "../context/files";
import LoginUser from "../context/login";
import LawFirm from "../context/lawfirm";

const Request: React.FC = () => {
  const [caseNumber, setCaseNumber]: any = useState("");
  const [caseType, setCaseType]: any = useState("");
  const [fileData, setFileData]: any = useState([]);
  const { fileRecord, setFileRecord }: any = useContext(FilesRecord);
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  const [comapany_id, set_comapany_id]: any = useState("");
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);

  useEffect(() => {
    if (lawfirm && loginUser.id !== undefined) {
      lawfirm.forEach((element: any) => {
        if (element.user_id === loginUser.id) {
          set_comapany_id(element.id);
        }
      });
    }
  }, [lawfirm]);

  //Add case file
  async function saveFile(e: any) {
    if (caseNumber === "" || caseType === "" || fileData.length <= 0) {
      Swal.fire({
        position: "center",
        icon: "warning",
        title: "All input fields are requred!",
        showConfirmButton: false,
        timer: 3000,
      });
      return;
    }
    const caseData: CreateCaseFileInput = {
      case_file_name: caseNumber,
      case_file_type: caseType,
      law_firm_id: comapany_id,
    };

    const newCaseFile: any = await API.graphql<
      GraphQLQuery<CreateCaseFileMutation>
    >({
      query: mutations.createCaseFile,
      variables: { input: caseData },
    });

    if (newCaseFile.data.createCaseFile) {
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener("mouseenter", Swal.stopTimer);
          toast.addEventListener("mouseleave", Swal.resumeTimer);
        },
      });

      Toast.fire({
        icon: "success",
        title: "New case file created successfully!",
      });
      uploadFile();

      setTimeout(function () {
        window.location.href = "/files";
      }, 2000);
    }
  }

  //S3 file upload
  async function uploadFile() {
    console.log(fileData.target.files[0]);
    fileRecord.forEach((file_element: any) => {
      if (file_element.key === fileData.target.files[0].name) {
        Swal.fire({
          position: "center",
          icon: "warning",
          title: "File name already exists!",
          showConfirmButton: false,
          timer: 3000,
        });
        return;
      }
    });
    const file = fileData.target.files[0];
    try {
      await Storage.put(file.name, file, {
        contentType: "image/pdf", // contentType is optional
      });
    } catch (error) {
      console.log("Error uploading file: ", error);
    }
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />
        <br />
        <br />

        <IonGrid>
          <IonRow className="main_row">
            <IonCol className="mobile_hide" size="2">
              {/* Request ection */}
              <IonCard className="main_card">
                <IonImg
                  className="card_img"
                  src="assets/undraw_Note_list_re_r4u9_r.png"
                  alt=""
                />
                <div className="card_con">
                  <IonCardHeader>
                    <IonCardTitle className="card_title">
                      Pick up request
                    </IonCardTitle>
                    <IonCardSubtitle className="card_title_sub">
                      Card Subtitle
                    </IonCardSubtitle>
                  </IonCardHeader>
                </div>
              </IonCard>
            </IonCol>

            {/* File upload section */}
            <IonCol>
              <IonCard className="main_card" style={{ padding: "5%" }}>
                <IonTitle
                  className="title_mobile"
                  color="medium"
                  style={{ textAlign: "right" }}
                >
                  <AiOutlineCloudUpload size="25" /> Upload case file
                </IonTitle>
                <hr />
                <IonItem>
                  <IonInput
                    label="Enter case number"
                    labelPlacement="floating"
                    placeholder="Enter text"
                    onIonChange={(e: any) => setCaseNumber(e.detail.value)}
                  ></IonInput>
                </IonItem>
                <IonItem>
                  <IonInput
                    label="Case type"
                    labelPlacement="floating"
                    placeholder="Enter text"
                    onIonChange={(e: any) => setCaseType(e.detail.value)}
                  ></IonInput>
                </IonItem>

                <IonItem>
                  <input
                    className="form-control"
                    type="file"
                    name="image"
                    onChange={(e) => setFileData(e)}
                    placeholder="Enter text"
                  ></input>
                </IonItem>
                <div style={{ textAlign: "left", padding: "1%" }}>
                  <IonButton
                    fill="outline"
                    color="medium"
                    shape="round"
                    className="btn_up"
                    onClick={(e) => saveFile(e)}
                  >
                    <BsFillCloudUploadFill size="20" /> Upload Case File
                  </IonButton>
                </div>
              </IonCard>
            </IonCol>
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Request;
