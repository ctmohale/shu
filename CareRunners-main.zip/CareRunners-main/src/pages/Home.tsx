import {
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonImg,
  IonItem,
  IonList,
  IonMenu,
  IonPage,
  IonRow,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { NavMobile } from "../components/NavMobile";
import Footer from "../components/Footer";
import { useContext, useEffect } from "react";
import LoginUser from "../context/login";
import FirmReg from "../components/FirmReg";
import UserMembershipMainData from "../context/userMembership";
import MebReg from "../components/MebReg";

const Home: React.FC = () => {
  const { loginUser }: any = useContext(LoginUser);
  const { userMembership, setUserMembership }: any = useContext(
    UserMembershipMainData
  );

  useEffect(() => {
    console.log(userMembership);
  }, [userMembership]);

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <div className="mobile_main_logo">
          <img src="assets/logo.png" width="50" />
          <IonTitle color="medium">Care Runners</IonTitle>
        </div>

        {loginUser.email !== undefined ? (
          <>
            {userMembership.access_type !== undefined ? (
              <div className="row home-row">
                <div className="col-sm-2">
                  <IonCard className="main_card" routerLink="/request">
                    <IonImg
                      className="card_img"
                      src="assets/undraw_Note_list_re_r4u9_r.png"
                      alt=""
                    />
                    <div className="card_con">
                      <IonCardHeader>
                        <IonCardTitle className="card_title">
                          <img
                            className="sub_icon"
                            src="assets/undraw_Note_list_re_r4u9_r.png"
                          />
                          Pick up request
                        </IonCardTitle>
                      </IonCardHeader>
                    </div>
                  </IonCard>
                </div>

                <div className="col-sm-2">
                  <IonCard className="main_card" routerLink="/upload">
                    <IonImg
                      className="card_img"
                      src="assets/undraw_add_document_re_mbjx.png"
                      alt=""
                    />

                    <div className="card_con">
                      <IonCardHeader>
                        <IonCardTitle className="card_title">
                          <img
                            className="sub_icon"
                            src="assets/undraw_add_document_re_mbjx.png"
                          />
                          Upload case file
                        </IonCardTitle>
                      </IonCardHeader>
                    </div>
                  </IonCard>
                </div>

                <div className="col-sm-2">
                  <IonCard className="main_card" routerLink="/files">
                    <IonImg
                      className="card_img"
                      src="assets/undraw_Filing_system_re_56h6.png"
                      alt=""
                    />
                    <div className="card_con">
                      <IonCardHeader>
                        <IonCardTitle className="card_title">
                          <img
                            className="sub_icon"
                            src="assets/undraw_Filing_system_re_56h6.png"
                          />
                          Firm records
                        </IonCardTitle>
                      </IonCardHeader>
                    </div>
                  </IonCard>
                </div>

                <div className="col-sm-2">
                  <IonCard className="main_card" routerLink="/profile">
                    <IonImg
                      className="card_img"
                      src="assets/undraw_profile_pic_ic5t.png"
                      alt=""
                    />
                    <div className="card_con">
                      <IonCardHeader>
                        <IonCardTitle className="card_title">
                          <img
                            className="sub_icon"
                            src="assets/undraw_profile_pic_ic5t.png"
                          />
                          Account profile
                        </IonCardTitle>
                      </IonCardHeader>
                    </div>
                  </IonCard>
                </div>

                <div className="col-sm-2">
                  <IonCard className="main_card" routerLink="/membership">
                    <IonImg
                      className="card_img"
                      src="assets/undraw_Server_re_twwj.png"
                      alt=""
                    />
                    <div className="card_con">
                      <IonCardHeader>
                        <IonCardTitle className="card_title">
                          <img
                            className="sub_icon"
                            src="assets/undraw_wallet_aym5-m.png"
                          />
                          Membership Access
                        </IonCardTitle>
                      </IonCardHeader>
                    </div>
                  </IonCard>
                </div>

                <div className="col-sm-2">
                  <IonCard className="main_card" routerLink="/billing">
                    <IonImg
                      className="card_img"
                      src="assets/undraw_wallet_aym5-m.png"
                      alt=""
                    />
                    <div className="card_con">
                      <IonCardHeader>
                        <IonCardTitle className="card_title">
                          <img
                            className="sub_icon"
                            src="assets/undraw_Note_list_re_r4u9_r.png"
                          />
                          Billing Info
                        </IonCardTitle>
                      </IonCardHeader>
                    </div>
                  </IonCard>
                </div>
              </div>
            ) : (
              <MebReg />
            )}
          </>
        ) : (
          <FirmReg />
        )}
      </IonContent>
    </IonPage>
  );
};

export default Home;
