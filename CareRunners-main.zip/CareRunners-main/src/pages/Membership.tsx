import {
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCheckbox,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonPage,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { TiStarburst } from "react-icons/ti";
import { BsPatchCheckFill } from "react-icons/bs";
import { GoLaw } from "react-icons/go";
import { useContext, useEffect, useRef, useState } from "react";
import Users from "../context/users";
import LoginUser from "../context/login";
import LawFirm from "../context/lawfirm";

import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { GraphQLQuery } from "@aws-amplify/api";
import Swal from "sweetalert2";
import { HashLoader } from "react-spinners";
import MembershipAccess from "../context/membership";
import UserMembershipMainData from "../context/userMembership";
import { MdOutlineCancel } from "react-icons/md";
import MembershipMainData from "../context/membershipMain";
import {
  UpdateMembershipAccessInput,
  UpdateMembershipAccessMutation,
  UpdateMembershipMutation,
} from "../API";
import { IoArrowBackCircleSharp } from "react-icons/io5";

const Membership: React.FC = () => {
  //Global var
  const { user, setUser }: any = useContext(Users);
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);
  const [isLoading, setIsloading]: any = useState(true);
  const { userMembership, setUserMembership }: any = useContext(
    UserMembershipMainData
  );
  const { membershipMain }: any = useContext(MembershipMainData);

  const modal = useRef<HTMLIonModalElement>(null);
  const page = useRef(undefined);
  const [memberDataSet, setMemberDataSet]: any = useState(null);
  const [lawFirmID, setLawFirmID]: any = useState();

  const [isOpen, setIsOpen]: any = useState(false);

  //Sweet Alert Toast
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  useEffect(() => {
    if (user.length > 0) {
      setIsloading(false);
    }
  }, [user]);

  useEffect(() => {
    console.log(userMembership);
  }, [userMembership]);

  useEffect(() => {
    if (userMembership.length > 0 && lawfirm.length > 0 && loginUser) {
      lawfirm.forEach((law_element: any) => {
        if (law_element.user_id === loginUser.id) {
          userMembership.map((data_element: any) => {
            if (data_element.law_firm_id === law_element.id) {
              setUserMembership(data_element);
            }
          });
        }
      });
    }
  }, [userMembership]);

  useEffect(() => {
    if (lawfirm.length > 0 && loginUser) {
      lawfirm.forEach((law_element: any) => {
        if (law_element.user_id === loginUser.id) {
          setLawFirmID(law_element.id);
        }
      });
    }
  }, [userMembership]);

  useEffect(() => {
    console.log(membershipMain);
  }, [membershipMain]);

  async function updateMbership() {
    console.log(memberDataSet);
    var id = memberDataSet.detail.value.id;
    var access = memberDataSet.detail.value.membership_type;
    var price = memberDataSet.detail.value.membership_price;
    if (memberDataSet !== null) {
      const memberData: UpdateMembershipAccessInput = {
        id: userMembership.id,
        access_type: access,
        membership_price: price,
      };
      const updatedTodo = await API.graphql<
        GraphQLQuery<UpdateMembershipAccessMutation>
      >({
        query: mutations.updateMembershipAccess,
        variables: { input: memberData },
      });
      if (updatedTodo) {
        Toast.fire({
          icon: "success",
          title: "Membership updated succefully!",
        });
      }
    }
    setIsOpen(false);
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />
        <br />
        <br />

        {isLoading && loginUser.email === undefined ? (
          <HashLoader color="#36d7b7" />
        ) : (
          <>
            {/* File upload section */}

            <IonCard className="main_card" style={{ padding: "5%" }}>
              <br />
              <br />
              <br />
              <IonTitle
                className="title_mobile"
                color="medium"
                style={{ textAlign: "left" }}
              >
                <BsPatchCheckFill size="25" /> Membership package
              </IonTitle>

              <div className="row m-0 p-0 pt-5">
                <div
                  className="col-sm-2 membership"
                  style={{
                    border:
                      userMembership.access_type === "Bronze Package"
                        ? "5px solid rgba(0, 156, 70, 0.616)"
                        : "",
                  }}
                >
                  <div className="card-body">
                    <br />
                    <h5 className="card-title text-secondary p-2">
                      Bronze Package
                    </h5>

                    <p className="card-text text-secondary">
                      RAM: 2 GB | Support & Maintenance
                    </p>
                    <p>
                      <b>R350.00</b>
                    </p>
                    <span
                      className="text-secondary"
                      style={{
                        border:
                          userMembership.access_type === "Bronze Package"
                            ? "rgba(0, 156, 70, 0.616)"
                            : "",
                      }}
                    >
                      <BsPatchCheckFill size="20" />
                    </span>
                    <br />
                    {userMembership.access_type === "Bronze Package" ? (
                      <IonButton
                        disabled
                        fill="outline"
                        shape="round"
                        color="success"
                        className="ion-margin"
                      >
                        Active
                      </IonButton>
                    ) : (
                      <IonButton
                        id="open_update_modal"
                        fill="outline"
                        shape="round"
                        color="medium"
                        className="ion-margin"
                        onClick={() => setIsOpen(true)}
                      >
                        Upgrade
                      </IonButton>
                    )}
                  </div>
                </div>
                <div
                  className="col-sm-2 membership"
                  style={{
                    border:
                      userMembership.access_type === "Silver Package"
                        ? "5px solid rgba(0, 156, 70, 0.616)"
                        : "",
                  }}
                >
                  <div className="card-body">
                    <br />
                    <h5 className="card-title text-secondary p-2">
                      Silver Package
                    </h5>
                    <p className="card-text text-secondary">
                      RAM: 4GB | Support & Maintenance
                    </p>
                    <p>
                      <b>R550.00</b>
                    </p>
                    <span
                      className="text-secondary"
                      style={{
                        border:
                          userMembership.access_type === "Bronze Package"
                            ? "rgba(0, 156, 70, 0.616)"
                            : "",
                      }}
                    >
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                    </span>
                    <br />
                    {userMembership.access_type === "Silver Package" ? (
                      <IonButton
                        disabled
                        fill="outline"
                        shape="round"
                        color="success"
                        className="ion-margin"
                      >
                        Active
                      </IonButton>
                    ) : (
                      <IonButton
                        fill="outline"
                        shape="round"
                        color="medium"
                        className="ion-margin"
                        onClick={() => setIsOpen(true)}
                      >
                        Upgrade
                      </IonButton>
                    )}
                  </div>
                </div>
                <div
                  className="col-sm-2 membership"
                  style={{
                    border:
                      userMembership.access_type === "Gold Package"
                        ? "5px solid rgba(0, 156, 70, 0.616)"
                        : "",
                  }}
                >
                  <div className="card-body">
                    <br />
                    <h5 className="card-title text-secondary p-2">
                      Gold Package
                    </h5>
                    <p className="card-text text-secondary">
                      RAM: 6GB | Support & Maintenance
                    </p>
                    <p>
                      <b>R650.00</b>
                    </p>
                    <span
                      className="text-secondary"
                      style={{
                        border:
                          userMembership.access_type === "Bronze Package"
                            ? "rgba(0, 156, 70, 0.616)"
                            : "",
                      }}
                    >
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                    </span>
                    <br />
                    {userMembership.access_type === "Gold Package" ? (
                      <IonButton
                        disabled
                        fill="outline"
                        shape="round"
                        color="success"
                        className="ion-margin"
                      >
                        Active
                      </IonButton>
                    ) : (
                      <IonButton
                        fill="outline"
                        shape="round"
                        color="medium"
                        className="ion-margin"
                        onClick={() => setIsOpen(true)}
                      >
                        Upgrade
                      </IonButton>
                    )}
                  </div>
                </div>
                <div
                  className="col-sm-2 membership"
                  style={{
                    border:
                      userMembership.access_type === "Platinum Package"
                        ? "5px solid rgba(0, 156, 70, 0.616)"
                        : "",
                  }}
                >
                  <div className="card-body">
                    <br />
                    <h5 className="card-title text-secondary p-2">
                      Platinum Package
                    </h5>
                    <p className="card-text text-secondary">
                      RAM: 4GB | Support & Maintenance
                    </p>
                    <p>
                      <b>R750.00</b>
                    </p>
                    <span>
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                    </span>
                    <br />
                    {userMembership.access_type === "Platinum Package" ? (
                      <IonButton
                        disabled
                        fill="outline"
                        shape="round"
                        color="success"
                        className="ion-margin"
                      >
                        Active
                      </IonButton>
                    ) : (
                      <IonButton
                        fill="outline"
                        shape="round"
                        color="medium"
                        className="ion-margin"
                        onClick={() => setIsOpen(true)}
                      >
                        Upgrade
                      </IonButton>
                    )}
                  </div>
                </div>
                <div
                  className="col-sm-2 membership"
                  style={{
                    border:
                      userMembership.access_type === "Palladium Package"
                        ? "5px solid rgba(0, 156, 70, 0.616)"
                        : "",
                  }}
                >
                  <div className="card-body">
                    <br />
                    <h5 className="card-title text-secondary p-2">
                      Palladium Package
                    </h5>
                    <p className="card-text text-secondary">
                      RAM: 6GB | Support & Maintenance
                    </p>
                    <p>
                      <b>R1 200.00</b>
                    </p>
                    <span
                      style={{
                        color:
                          userMembership.access_type === "Bronze Package"
                            ? "rgba(0, 156, 70, 0.616);"
                            : "",
                      }}
                    >
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                      <BsPatchCheckFill size="20" />
                    </span>
                    <br />
                    {userMembership.access_type === "Palladium Package" ? (
                      <IonButton
                        disabled
                        fill="outline"
                        shape="round"
                        color="success"
                        className="ion-margin"
                      >
                        Active
                      </IonButton>
                    ) : (
                      <IonButton
                        fill="outline"
                        shape="round"
                        color="medium"
                        className="ion-margin"
                        onClick={() => setIsOpen(true)}
                      >
                        Upgrade
                      </IonButton>
                    )}
                  </div>
                </div>
              </div>
              <br />
              <br />
            </IonCard>
          </>
        )}

        <IonModal
          className="request_modal"
          ref={modal}
          trigger="open_update_modal"
          isOpen={isOpen}
          onWillDismiss={() => setIsOpen(false)}
        >
          <IonHeader className="request_header">
            <IonToolbar className="request_tool_bar ion-padding">
              <p className="text-secondary"></p>
              <IonButtons slot="end">
                <IonButton
                  color="medium"
                  shape="round"
                  fill="outline"
                  onClick={() => setIsOpen(false)}
                >
                  Cancel <IoArrowBackCircleSharp size="25" />
                </IonButton>
              </IonButtons>
            </IonToolbar>
          </IonHeader>
          <IonContent className="ion-padding text-center p-5">
            <span className="text-warning">
              <TiStarburst size="50" />
            </span>
            <h1 className="text-secondary">Membership Types</h1>
            <IonItem className="p-4">
              <IonSelect
                aria-label="Fruit"
                interface="popover"
                placeholder="Select membership type"
                onIonChange={(e: any) => setMemberDataSet(e)}
              >
                {membershipMain &&
                  membershipMain.map((data_element: any) => {
                    return (
                      <IonSelectOption
                        key={data_element.id}
                        value={data_element}
                      >
                        {data_element.membership_type}
                      </IonSelectOption>
                    );
                  })}
              </IonSelect>
            </IonItem>
            <IonButton
              onClick={() => updateMbership()}
              color="medium"
              shape="round"
            >
              Complete Update
            </IonButton>
          </IonContent>
        </IonModal>
      </IonContent>
    </IonPage>
  );
};

export default Membership;
