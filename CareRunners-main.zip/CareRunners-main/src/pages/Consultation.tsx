import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonPage,
  IonRow,
  IonTitle,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { BsFillCloudUploadFill } from "react-icons/bs";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { AiFillEdit } from "react-icons/ai";
import { MdDeleteSweep } from "react-icons/md";
import CaseFile from "../context/casefile";
import { useContext, useState, useEffect, CSSProperties } from "react";
import { BounceLoader, HashLoader, RingLoader } from "react-spinners";
import Swal from "sweetalert2";
import { DeleteCaseFileInput, DeleteCaseFileMutation } from "../API";
import { GraphQLQuery } from "@aws-amplify/api";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";

const Consultation: React.FC = () => {
  const { casefile, setCasefile }: any = useContext(CaseFile);
  const [loading, setLoading]: any = useState(true);
  const [recordId, setRecordId]: any = useState();
  const [isLoading, setIsloading]: any = useState(true);
  useEffect(() => {
    if (casefile != null) {
      setLoading(false);
    }
  }, [casefile]);

  useEffect(() => {
    if (casefile.length > 0) {
      setIsloading(false);
    }
  }, [casefile]);

  const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
    borderColor: "red",
  };

  async function deleteConfirm(id: any) {
    const Toast = Swal.mixin({
      toast: true,
      position: "center",
      showConfirmButton: true,
      showCancelButton: true,
      confirmButtonColor: "rgba(216, 14, 0, 0.603)", // Set the button color to red
      customClass: {
        confirmButton: "custom-confirm-button",
        cancelButton: "custom-confirm-button",
      },
      timer: 10000,
      timerProgressBar: true,
      didOpen: (toast) => {
        toast.addEventListener("mouseenter", Swal.stopTimer);
        toast.addEventListener("mouseleave", Swal.resumeTimer);
      },
    });

    Toast.fire({
      icon: "error",
      title: "Are you sure you to delete record!",
    }).then((result) => {
      if (result.isConfirmed) {
        deleteCaseFileFunction(id);
      }
    });
  }

  //Delete case file
  async function deleteCaseFileFunction(id: any) {
    let caseFile: DeleteCaseFileInput = {
      id: id,
    };
    const deletedTodo = await API.graphql<GraphQLQuery<DeleteCaseFileMutation>>(
      {
        query: mutations.deleteCaseFile,
        variables: { input: caseFile },
      }
    );

    if (deletedTodo.data) {
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener("mouseenter", Swal.stopTimer);
          toast.addEventListener("mouseleave", Swal.resumeTimer);
        },
      });

      Toast.fire({
        icon: "success",
        title: "Record deleted successfully!",
      });
    }
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />

        {loading != true ? (
          <IonGrid>
            <IonRow className="main_row">
              <IonCol className="mobile_hide" size="2">
                {/* Request ection */}
                <IonCard className="main_card">
                  <IonImg
                    className="card_img"
                    src="assets/undraw_Note_list_re_r4u9_r.png"
                    alt=""
                  />
                  <div className="card_con">
                    <IonCardHeader>
                      <IonCardTitle className="card_title">
                        Pick up request
                      </IonCardTitle>
                      <IonCardSubtitle className="card_title_sub">
                        Card Subtitle
                      </IonCardSubtitle>
                    </IonCardHeader>
                  </div>
                </IonCard>
              </IonCol>

              {/* File upload section */}
       
                <IonCol>
                  <IonCard className="main_card" style={{ padding: "5%" }}>
                    <IonTitle
                      className="title_mobile"
                      color="medium"
                      style={{ textAlign: "right" }}
                    >
                      <AiOutlineCloudUpload size="25" /> Case files
                    </IonTitle>
                    <hr />
                    <IonGrid>
                      <IonRow className="file_lable">
                        <IonCol
                          className="mobile_hide"
                          style={{ textAlign: "left" }}
                        >
                          ID
                        </IonCol>
                        <IonCol style={{ textAlign: "left" }}>Case File</IonCol>
                        <IonCol
                          className="mobile_hide"
                          style={{ textAlign: "left" }}
                        >
                          File Type
                        </IonCol>
                        <IonCol style={{ textAlign: "left" }}>
                          View Document
                        </IonCol>
                        <IonCol className="col">Update</IonCol>
                        <IonCol className="col mobile_hide">Delete</IonCol>
                      </IonRow>

                    
                        
      
                    </IonGrid>
                  </IonCard>
                </IonCol>
              
            </IonRow>
          </IonGrid>
        ) : (
          <div className="loader">
            <BounceLoader cssOverride={override} color="rgb(2, 124, 133)" />
          </div>
        )}
      </IonContent>
    </IonPage>
  );
};

export default Consultation;
