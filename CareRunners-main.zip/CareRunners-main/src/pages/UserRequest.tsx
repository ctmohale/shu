import {
  IonButton,
  IonButtons,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonHeader,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonModal,
  IonPage,
  IonRadio,
  IonRadioGroup,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import React, { useState, useRef, useEffect, useContext } from "react";
import { OverlayEventDetail } from "@ionic/core/components";
import { GraphQLSubscription } from "@aws-amplify/api";

import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { GraphQLQuery } from "@aws-amplify/api";

import "./Home.css";
import Nav from "../components/Nav";
import { AiFillEdit, AiOutlineCar, AiOutlineCloudUpload } from "react-icons/ai";
import { TfiLocationPin } from "react-icons/tfi";
import { FaCar } from "react-icons/fa";
import { IoArrowBackCircleSharp } from "react-icons/io5";
import { caretDownSharp } from "ionicons/icons";
import {
  CreatePickUpRequestInput,
  CreatePickUpRequestMutation,
  DeletePickUpRequestInput,
  DeletePickUpRequestMutation,
  OnDeletePickUpRequestSubscription,
} from "../API";
import Swal from "sweetalert2";
import PickUprequest from "../context/request";
import { AiFillCar } from "react-icons/ai";
import { MdDeleteSweep } from "react-icons/md";
import { TbEdit } from "react-icons/tb";
import RequestUpdate from "../components/RequestUpdate";
import * as subscriptions from "../graphql/subscriptions";
import { graphqlOperation } from "aws-amplify";
import { HashLoader } from "react-spinners";
import LawFirm from "../context/lawfirm";
import LoginUser from "../context/login";

function UserRequest() {
  const modal = useRef<HTMLIonModalElement>(null);
  const input = useRef<HTMLIonInputElement>(null);
  const [requestType, setRequestType]: any = useState();
  const [requestDeliveryType, setRequestDeliveryType]: any = useState();
  const [destination, setDestination]: any = useState();
  const [resCell, setResCell]: any = useState();
  const [resFullName, setResFullName]: any = useState();
  const [desBool, setDestBool]: any = useState(false);
  const { pickRequest, setPickUprequest }: any = useContext(PickUprequest);
  const [urlData, setUrlData]: any = useState(false);
  const [isLoading, setIsloading]: any = useState(true);
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);
  const [comapany_id, set_comapany_id]: any = useState("");
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  //Google places API
  const [predictions, setPredictions]: any = useState([]);

  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  useEffect(() => {
    if (lawfirm && loginUser.id !== undefined) {
      lawfirm.forEach((element: any) => {
        if (element.user_id === loginUser.id) {
          set_comapany_id(element.id);
        }
      });
    }
  }, [lawfirm]);

  useEffect(() => {
    if (window.location.search.search("id")) {
      setUrlData(true);
    }
  }, []);

  useEffect(() => {
    if (pickRequest) {
      setIsloading(false);
    }
  }, [pickRequest]);

  //Add requert
  async function newPickUpRequestFunction() {
    if (
      resFullName === undefined ||
      resCell === undefined ||
      requestDeliveryType === undefined ||
      requestType === undefined
    ) {
      Toast.fire({
        icon: "warning",
        title: "All input are required!",
      });

      return;
    }
    const requestDetails: CreatePickUpRequestInput = {
      destination_address: destination,
      lat: "",
      lng: "",
      law_firm_id: comapany_id,
      recipient_full_names: resFullName,
      recipient_cell_no: resCell,
      request_delivery_state: requestDeliveryType,
      request_type: requestType,
      request_status: "Pending",
    };

    const newPickUpRequest = await API.graphql<
      GraphQLQuery<CreatePickUpRequestMutation>
    >({
      query: mutations.createPickUpRequest,
      variables: { input: requestDetails },
    });

    if (newPickUpRequest.data) {
      Toast.fire({
        icon: "success",
        title: "Pick-Up request submited successfully!",
      });

      setInterval(() => {
        window.location.replace("/request");
      }, 2000);
    }
  }

  //Modal
  const handlePlaceInputChange = (event: any) => {
    if (desBool == true) {
      setDestination("");
    }
    const input = event.target.value;
    if (!input) {
      setPredictions([]);
      return;
    }

    const autocompleteService =
      new window.google.maps.places.AutocompleteService();
    autocompleteService.getPlacePredictions(
      {
        input: input,
        types: ["(regions)"], // You can adjust the types as per your requirements
      },
      (predictions: any, status: any) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK) {
          setPredictions(predictions);
        } else {
          setPredictions([]);
        }
      }
    );
  };

  return (
    <IonPage>
      <IonContent>
        {/* Navigation section */}
        <Nav />

        <IonGrid>
          <IonRow className="main_row">
            <IonCol className="side_col_r" size="2">
              {/* Request ection */}
              <IonCard className="main_card">
                <IonImg
                  className="card_img"
                  src="assets/undraw_Note_list_re_r4u9_r.png"
                  alt=""
                />

                <div className="card_con">
                  <IonCardHeader>
                    <IonCardTitle className="card_title">
                      Request Pickup
                    </IonCardTitle>

                    <IonCardSubtitle className="card_title_sub">
                      <AiOutlineCar size="30" />
                    </IonCardSubtitle>
                  </IonCardHeader>
                </div>
              </IonCard>
            </IonCol>

            {/* File upload section */}

            {isLoading ? (
              <HashLoader color="#36d7b7" />
            ) : (
              <IonCol>
                <br />
                <br />
                <IonCard className="main_card" style={{ padding: "5%" }}>
                  <IonTitle
                    className="title_mobile"
                    color="medium"
                    style={{ textAlign: "right" }}
                  >
                    <AiOutlineCar size="25" /> Request Pick-up
                  </IonTitle>
                  <hr />

                  {destination ? (
                    <IonItem>
                      <IonInput
                        placeholder="*Enter destination"
                        onIonInput={handlePlaceInputChange}
                        value={destination}
                      ></IonInput>
                    </IonItem>
                  ) : (
                    <IonItem>
                      <IonInput
                        placeholder="*Enter destination"
                        onIonInput={handlePlaceInputChange}
                      ></IonInput>
                    </IonItem>
                  )}

                  {predictions.length > 0 && (
                    <IonItem color="light" className="p-4">
                      <IonRadioGroup
                        class="w-100 p-3"
                        onIonChange={(e: any) => setDestination(e.detail.value)}
                      >
                        {predictions.map((prediction: any) => (
                          <IonRadio
                            className="radio_btn"
                            value={prediction.description}
                            id={prediction.place_id}
                            key={prediction.place_id}
                          >
                            {prediction.description}
                          </IonRadio>
                        ))}
                      </IonRadioGroup>
                    </IonItem>
                  )}

                  <IonItem>
                    <IonInput
                      label="*Recepient full names"
                      labelPlacement="floating"
                      placeholder="Full names"
                      onIonChange={(e: any) => setResFullName(e.detail.value)}
                    ></IonInput>
                  </IonItem>

                  <IonItem>
                    <IonInput
                      label="*Recepient cell-no"
                      labelPlacement="floating"
                      placeholder="Cell phone number"
                      onIonChange={(e: any) => setResCell(e.detail.value)}
                    ></IonInput>
                  </IonItem>

                  <IonItem>
                    <IonSelect
                      className="never-flip"
                      interface="popover"
                      label="*Request type"
                      placeholder="Normal"
                      onIonChange={(e: any) => setRequestType(e.detail.value)}
                    >
                      <IonSelectOption value="Pick up request">
                        Pick up request
                      </IonSelectOption>
                      <IonSelectOption value="Ride request">
                        Ride request
                      </IonSelectOption>
                      <IonSelectOption value="Other">Other</IonSelectOption>
                    </IonSelect>
                  </IonItem>

                  <IonItem>
                    <IonSelect
                      className="never-flip"
                      interface="popover"
                      label="*Delivery state"
                      placeholder="Normal"
                      onIonChange={(e: any) =>
                        setRequestDeliveryType(e.detail.value)
                      }
                    >
                      <IonSelectOption value="Normal">
                        Normal pick-up
                      </IonSelectOption>
                      <IonSelectOption value="Ergent">
                        Ergent pick-up
                      </IonSelectOption>
                    </IonSelect>
                  </IonItem>

                  <div style={{ textAlign: "left" }}>
                    <IonButton
                      className="ion-margin"
                      shape="round"
                      fill="outline"
                      color="medium"
                      onClick={() => newPickUpRequestFunction()}
                    >
                      Submit request
                    </IonButton>
                  </div>
                  <br />
                  <br />
                </IonCard>
              </IonCol>
            )}
          </IonRow>
        </IonGrid>
      </IonContent>
    </IonPage>
  );
}

export default UserRequest;
