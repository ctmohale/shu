import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonItemDivider,
  IonLabel,
  IonPage,
  IonRadioGroup,
  IonRow,
  IonSelect,
  IonSelectOption,
  IonTitle,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import {
  AiFillCar,
  AiOutlineCar,
  AiOutlineCloudUpload,
  AiOutlineUser,
} from "react-icons/ai";
import { useState, useEffect } from "react";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import {
  CreateCaseFileInput,
  CreateCaseFileMutation,
  GetPickUpRequestQuery,
} from "../API";
import { GraphQLQuery } from "@aws-amplify/api";
import Swal from "sweetalert2";
import { text } from "ionicons/icons";
import * as queries from "../graphql/queries";
import { useLocation } from "react-router";
import { FaCarSide } from "react-icons/fa";
import { FiSmartphone } from "react-icons/fi";
import { IoLocationSharp, IoWarningOutline } from "react-icons/io5";
import Map from "../components/Map";
import { HashLoader } from "react-spinners";
import { HiOutlineCollection } from "react-icons/hi";

const Update: React.FC = (url) => {
  const [caseNumber, setCaseNumber]: any = useState("");
  const [caseType, setCaseType]: any = useState("");
  const [requesData, setRequestData]: any = useState();
  const [isLoading, setIsloading]: any = useState(true);

  const [requestType, setRequestType]: any = useState();
  const [requestDeliveryType, setRequestDeliveryType]: any = useState();
  const [destination, setDestination]: any = useState();
  const [resCell, setResCell]: any = useState();
  const [resFullName, setResFullName]: any = useState();

  //
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const id: any = searchParams.get("id");

  useEffect(() => {
    getRequest();
  }, [id]);

  useEffect(() => {
    if (requesData) {
      setRequestType(requesData.request_type);
      setRequestDeliveryType(requesData.request_delivery_state);
      setDestination(requesData.destination_address);
      setResFullName(requesData.recipient_full_names);
      setResCell(requesData.recipient_cell_no);
      setIsloading(false);
    }
  }, [requesData]);

  // Fetch a single record by its identifier
  async function getRequest() {
    const getReq: any = await API.graphql<GraphQLQuery<GetPickUpRequestQuery>>({
      query: queries.getPickUpRequest,
      variables: { id: id },
    });
    setRequestData(getReq.data.getPickUpRequest);
    console.log(getReq.data.getPickUpRequest);
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />
        <br />
        <br />
        <div className="row update-section">
          {isLoading ? (
            <div className="loaderU">
              <HashLoader color="#36d7b7" />
            </div>
          ) : (
            <>
              {/*  Request update info  */}
              <div className="col-sm-6" style={{ padding: "2%" }}>
                <IonTitle
                  className="title_mobile"
                  color="medium"
                  style={{ textAlign: "right" }}
                >
                  <AiOutlineCar size="25" /> Request Status
                  <IonItemDivider>
                    <IonLabel></IonLabel>
                  </IonItemDivider>
                </IonTitle>

                {requesData != null ? (
                  <>
                    {requesData.request_status === "Pending" ? (
                      <IonItem
                        className="right_item alert"
                        button
                        detail={true}
                      >
                        <IonLabel className="LableAlert">
                          <h2>
                            <b>
                              <FaCarSide /> Awaiting driver acceptance !
                            </b>
                          </h2>
                          <p style={{ padding: "3%" }}>
                            Please wait while the system is seaching for
                            drivers!
                          </p>
                        </IonLabel>
                      </IonItem>
                    ) : requesData.request_status === "Accepted" ? (
                      <div className="row updateRowMapDriver">
                        <div className="col-sm-6">
                          <div>
                            <IonItem
                              className="itemDriverInfo"
                              style={{ borderRadius: "20px" }}
                            >
                              <IonLabel>
                                <h2 className="p-2">
                                  <b className="text-success">
                                    Request Accepted !
                                  </b>
                                </h2>

                                <IonRow>
                                  <IonCol>
                                    <HiOutlineCollection />
                                    Pick-up Time
                                  </IonCol>
                                  <IonCol>1h 50m</IonCol>
                                </IonRow>

                                <IonRow>
                                  <IonCol>
                                    <AiOutlineUser /> Driver Name
                                  </IonCol>
                                  <IonCol>Christopher</IonCol>
                                </IonRow>

                                <IonRow>
                                  <IonCol>
                                    <FiSmartphone /> Driver Cell No
                                  </IonCol>
                                  <IonCol>0743642496</IonCol>
                                </IonRow>

                                <IonRow>
                                  <IonCol>
                                    <AiOutlineCar /> Car registration
                                  </IonCol>
                                  <IonCol>KG 142</IonCol>
                                </IonRow>
                              </IonLabel>
                            </IonItem>
                            <br />
                          </div>
                        </div>
                        <div className="col-sm-6">
                          <div className="mapSideSection p-">
                            <Map />
                          </div>
                        </div>
                      </div>
                    ) : requesData.request_status === "Collected" ? (
                      <IonItem className="right_item" button detail={true}>
                        <IonLabel>
                          <h2>
                            <b>
                              <IoLocationSharp /> Location tracking
                            </b>
                          </h2>
                          <p style={{ padding: "3%" }}>
                            Detail set to true - detail arrow displays on both
                            modes
                          </p>
                        </IonLabel>
                      </IonItem>
                    ) : (
                      ""
                    )}
                  </>
                ) : (
                  ""
                )}
              </div>

              {/* Update */}
              {requesData != null && (
                <div className="col-sm-6" style={{ padding: "2%" }}>
                  <IonTitle
                    className="title_mobile"
                    color="medium"
                    style={{ textAlign: "right" }}
                  >
                    <AiOutlineCar size="25" /> Update request
                  </IonTitle>
                  <hr />
                  <IonItem disabled>
                    <IonInput
                      placeholder="Enter destination"
                      value={destination}
                    ></IonInput>
                  </IonItem>

                  <IonItem disabled>
                    <IonInput
                      label="Recepient full names"
                      labelPlacement="floating"
                      placeholder="Full names"
                      value={resFullName}
                    ></IonInput>
                  </IonItem>

                  <IonItem disabled>
                    <IonInput
                      label="Recepient cell-no"
                      labelPlacement="floating"
                      placeholder="Cell phone number"
                      value={resCell}
                    ></IonInput>
                  </IonItem>

                  <IonItem disabled>
                    <IonSelect
                      className="never-flip"
                      interface="popover"
                      label="Request type"
                      placeholder="Normal"
                      value={requesData.request_type}
                    >
                      <IonSelectOption value="Pick up request">
                        Pick up request
                      </IonSelectOption>
                      <IonSelectOption value="Other">Other</IonSelectOption>
                    </IonSelect>
                  </IonItem>

                  <IonItem disabled>
                    <IonSelect
                      className="never-flip"
                      interface="popover"
                      label="Delivery state"
                      placeholder="Normal"
                      value={requesData.request_delivery_state}
                    >
                      <IonSelectOption value="Normal">
                        Normal pick-up
                      </IonSelectOption>
                      <IonSelectOption value="Ergent">
                        Ergent pick-up
                      </IonSelectOption>
                    </IonSelect>
                  </IonItem>

                  <IonButton
                    disabled
                    className="btn-request-update margin-top ion-margin"
                    shape="round"
                    fill="outline"
                    color="medium"
                  >
                    <AiOutlineCar /> Update request info
                  </IonButton>
                  <small className="text-warning">
                    <IoWarningOutline /> No Available
                  </small>
                </div>
              )}
            </>
          )}
        </div>
        <br />
        <br />
        <br />
        <br />

      </IonContent>
    </IonPage>
  );
};

export default Update;
