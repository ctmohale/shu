import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonPage,
  IonRow,
  IonTitle,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { BsFillCloudUploadFill } from "react-icons/bs";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { AiFillEdit } from "react-icons/ai";
import { MdDeleteSweep, MdPolicy } from "react-icons/md";
import CaseFile from "../context/casefile";
import { useContext, useState, useEffect, CSSProperties } from "react";
import { BounceLoader, HashLoader, RingLoader } from "react-spinners";
import Swal from "sweetalert2";
import { DeleteCaseFileInput, DeleteCaseFileMutation } from "../API";
import { GraphQLQuery } from "@aws-amplify/api";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";

const Policies: React.FC = () => {
  const { casefile, setCasefile }: any = useContext(CaseFile);
  const [loading, setLoading]: any = useState(true);
  const [recordId, setRecordId]: any = useState();
  const [isLoading, setIsloading]: any = useState(true);
  useEffect(() => {
    if (casefile != null) {
      setLoading(false);
    }
  }, [casefile]);

  //Delete case file
  async function deleteCaseFileFunction(id: any) {
    let caseFile: DeleteCaseFileInput = {
      id: id,
    };
    const deletedTodo = await API.graphql<GraphQLQuery<DeleteCaseFileMutation>>(
      {
        query: mutations.deleteCaseFile,
        variables: { input: caseFile },
      }
    );

    if (deletedTodo.data) {
      const Toast = Swal.mixin({
        toast: true,
        position: "top-end",
        showConfirmButton: false,
        timer: 3000,
        timerProgressBar: true,
        didOpen: (toast) => {
          toast.addEventListener("mouseenter", Swal.stopTimer);
          toast.addEventListener("mouseleave", Swal.resumeTimer);
        },
      });

      Toast.fire({
        icon: "success",
        title: "Record deleted successfully!",
      });
    }
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />
        <br />
        <br />
       
        <IonGrid>
          <IonRow className="main_row">
            {/* File upload section */}
            <IonCol>
              <IonCard className="main_card" style={{ padding: "5%" }}>
                <IonTitle
                  className="title_mobile"
                  color="medium"
                  style={{ textAlign: "right" }}
                >
                  <MdPolicy size="25" /> Care Runners Policy section
                </IonTitle>

                <div className="row">
                  <div className="col-sm-3 mb-3 mb-sm-0">
                    <div className="card mb-4">
                      <IonTitle className="ion-padding">
                        Private Policy for Customers
                      </IonTitle>

                      <iframe
                        src="./assets/Private Policy for  Customers.pdf"
                        width="100%"
                        height="300px"
                      ></iframe>
                    </div>

                    <IonButton shape="round" color="medium" fill="clear">
                      Accept
                    </IonButton>
                    <IonButton shape="round" color="danger" fill="clear">
                      Reject
                    </IonButton>
                    <br />
                    <br />
                  </div>
                  <div className="col-sm-3">
                    <div className="card mb-4">
                      <IonTitle className="ion-padding">
                        Table of Contents
                      </IonTitle>

                      <iframe
                        src="./assets/Table of Contents.pdf"
                        width="100%"
                        height="300px"
                      ></iframe>
                    </div>
                    <IonButton shape="round" color="medium" fill="clear">
                      Accept
                    </IonButton>
                    <IonButton shape="round" color="danger" fill="clear">
                      Reject
                    </IonButton>
                    <br />
                    <br />
                  </div>
                  <br />
                  <br />
                  <div className="col-sm-3">
                    <div className="card mb-4">
                      <IonTitle className="ion-padding">
                        Terms and Conditions Agreement Driver Care Runners
                      </IonTitle>

                      <iframe
                        src="./assets/Terms and Conditions Agreement Driver Care Runners.pdf"
                        width="100%"
                        height="300px"
                      ></iframe>
                    </div>
                    <IonButton shape="round" color="medium" fill="clear">
                      Accept
                    </IonButton>
                    <IonButton shape="round" color="danger" fill="clear">
                      Reject
                    </IonButton>
                    <br />
                    <br />
                  </div>
                  <br />
                  <br />

                  <br />
                  <br />
                  <div className="col-sm-3">
                    <div className="card mb-4">
                      <IonTitle className="ion-padding">
                        Terms_and_Conditions_For_Law Firms
                      </IonTitle>

                      <iframe
                        src="./assets/Terms_and_Conditions_For_Law Firms.pdf"
                        width="100%"
                        height="300px"
                      ></iframe>
                    </div>
                    <IonButton shape="round" color="medium" fill="clear">
                      Accept
                    </IonButton>
                    <IonButton shape="round" color="danger" fill="clear">
                      Reject
                    </IonButton>
                    <br />
                    <br />
                  </div>
                  <br />
                  <br />
                </div>
              </IonCard>
            </IonCol>
          </IonRow>
          <br />
          <br />
          <br />
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Policies;
