import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonPage,
  IonRow,
  IonText,
  IonTitle,
} from "@ionic/react";
import "./Home.css";
import Nav from "../components/Nav";
import { RiMoneyDollarCircleFill } from "react-icons/ri";
import { AiOutlineUser } from "react-icons/ai";
import { TbServerBolt } from "react-icons/tb";
import { IoServerOutline } from "react-icons/io5";
import { BiCar } from "react-icons/bi";
import { useContext, useEffect, useState } from "react";
import UserMembershipMainData from "../context/userMembership";
import MembershipMainData from "../context/membershipMain";

const Billing: React.FC = () => {
  const { userMembership, setUserMembership }: any = useContext(
    UserMembershipMainData
  );
  const { membershipMain }: any = useContext(MembershipMainData);
  const [totalAmount, setTotalAmount]: any = useState(0);

  useEffect(() => {
    console.log(userMembership);

    if (userMembership !== null) {
      setTotalAmount(userMembership.membership_price);
    }
  }, [userMembership]);

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />
        <br />
        <IonGrid>
          <IonRow className="main_row">
            <IonCol className="mobile_hide" size="2">
              <IonCard className="main_card" routerLink="/billing">
                <IonImg
                  className="card_img"
                  src="assets/undraw_wallet_aym5-m.png"
                  alt=""
                />
                <div className="card_con">
                  <IonCardHeader>
                    <IonCardTitle className="card_title">
                      Billing Information
                    </IonCardTitle>
                    <IonCardSubtitle className="card_title_sub">
                      Card Subtitle
                    </IonCardSubtitle>
                  </IonCardHeader>
                </div>
              </IonCard>
            </IonCol>

            {/* File upload section */}

            {userMembership && (
              <IonCol>
                <IonCard className="main_card" style={{ padding: "5%" }}>
                  <IonTitle
                    className="tite_mobile_billing"
                    color="medium"
                    style={{ textAlign: "right" }}
                  >
                    <RiMoneyDollarCircleFill size="30" /> Billing Information
                  </IonTitle>
                  <br />
                  <IonItem detail={true} className="top-billing-section">
                    <IonLabel>
                      <h3 className="billingTitle">
                        <b>
                          <AiOutlineUser /> Membership
                        </b>
                      </h3>
                      <p className="p-2">Active</p>
                    </IonLabel>
                  </IonItem>

                  <IonItem detail={true}>
                    <IonLabel>
                      <h3 className="billingTitle">
                        <b>
                          <TbServerBolt /> Membership Fee
                        </b>
                      </h3>
                      <p className="p-2">
                        {userMembership.access_type} : R
                        {userMembership.membership_price}
                      </p>
                    </IonLabel>
                  </IonItem>
                  <IonItem detail={true}>
                    <IonLabel>
                      <h3 className="billingTitle">
                        <b>
                          <IoServerOutline /> Consultaion fees
                        </b>
                      </h3>
                      <p className="p-2">Total : R0</p>
                    </IonLabel>
                  </IonItem>
                  <IonItem detail={true}>
                    <IonLabel>
                      <h3 className="billingTitle">
                        <b>
                          <BiCar /> Delivery fees
                        </b>
                      </h3>
                      <p className="p-2">Total request fee : R0</p>
                    </IonLabel>
                  </IonItem>

                  <IonItem detail={true}>
                    <h3 className="text-secondary">
                      <IonText color="medium">
                        Total amount due : R {totalAmount}
                      </IonText>
                    </h3>
                  </IonItem>
                </IonCard>
              </IonCol>
            )}
          </IonRow>
          <br />
          <br />
          <br />
        </IonGrid>
      </IonContent>
    </IonPage>
  );
};

export default Billing;
