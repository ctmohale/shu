import { Redirect, Route } from "react-router-dom";
import {
  IonApp,
  IonIcon,
  IonLabel,
  IonRouterOutlet,
  IonTabBar,
  IonTabButton,
  IonTabs,
  setupIonicReact,
} from "@ionic/react";
import { IonReactRouter } from "@ionic/react-router";
import { ellipse, square, triangle } from "ionicons/icons";

/* Core CSS required for Ionic components to work properly */
import "@ionic/react/css/core.css";

/* Basic CSS for apps built with Ionic */
import "@ionic/react/css/normalize.css";
import "@ionic/react/css/structure.css";
import "@ionic/react/css/typography.css";

/* Optional CSS utils that can be commented out */
import "@ionic/react/css/padding.css";
import "@ionic/react/css/float-elements.css";
import "@ionic/react/css/text-alignment.css";
import "@ionic/react/css/text-transformation.css";
import "@ionic/react/css/flex-utils.css";
import "@ionic/react/css/display.css";

/* Theme variables */
import "./theme/variables.css";
import Home from "./pages/Home";
import Request from "./pages/Request";
import Upload from "./pages/Upload";
import Files from "./pages/Files";
import Profile from "./pages/Profile";
import Consultation from "./pages/Consultation";
import Billing from "./pages/Billing";
import { Amplify, Auth, Storage } from "aws-amplify";
import { withAuthenticator } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import awsExports from "./aws-exports";
import { SignInHeader } from "./login/SignInHeader";
import { SignInFooter } from "./login/SignInFooter";
import { SignUpHeader } from "./login/SignUpHeader";
import { PasswordResetHeader } from "./login/PasswordResetHeader";
import { API, graphqlOperation } from "aws-amplify";
import * as queries from "./graphql/queries";
import { GraphQLQuery } from "@aws-amplify/api";
import {
  ListCaseFilesQuery,
  ListLawFirmsQuery,
  ListMembershipAccessesQuery,
  ListMembershipsQuery,
  ListPickUpRequestsQuery,
  ListUsersQuery,
  OnCreateCaseFileSubscription,
  OnDeletePickUpRequestSubscription,
  OnUpdateLawFirmSubscription,
  OnUpdateMembershipAccessSubscription,
  OnUpdateUserSubscription,
} from "./API";
import { useEffect, useState } from "react";
import Users from "./context/users";
import CaseFile from "./context/casefile";
import LawFirm from "./context/lawfirm";
import PickUprequest from "./context/request";
import RequestUpdate from "./components/RequestUpdate";
import Update from "./pages/Update";
import { GraphQLSubscription } from "@aws-amplify/api";
import * as subscriptions from "./graphql/subscriptions";
import { OnCreatePickUpRequestSubscription } from "./API";
import Swal from "sweetalert2";
import LoginUser from "./context/login";
import Nav from "./components/Nav";
import "./App.css";
import Footer from "./components/Footer";
import FilesRecord from "./context/files";
import UpdateFile from "./pages/UpdateFile";
import ReadFile from "./pages/ReadFile";
import MembershipAccess from "./context/membership";
import Membership from "./pages/Membership";
import MembershipMainData from "./context/membershipMain";
import UserMembershipMainData from "./context/userMembership";
import Policies from "./pages/Policies";
import AuthSetEmail from "./context/authEmail";
import UserRequest from "./pages/UserRequest";

Amplify.configure(awsExports);

setupIonicReact();
(window as any).global = window;

function App() {
  //Global variables
  const [user, setUser]: any = useState([]);
  const [casefile, setCasefile]: any = useState([]);
  const [lawfirm, setLawfirm]: any = useState([]);
  const [pickRequest, setPickUprequest]: any = useState();
  const [loginUser, setLoginUser]: any = useState([]);
  const [fileRecord, setFileRecord]: any = useState([]);
  const [membershipAccess, setMembershipAccess]: any = useState([]);
  const [membershipMain, setMembershipmain]: any = useState([]);
  const [userMembership, setUserMembership]: any = useState([]);
  const [tempEmailAuth, setTempEmailAuth]: any = useState(null);
  const [signedUrls, setSignedUrls] = useState([]);

  //Sweet Alert Toast
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  //Set membership
  useEffect(() => {
    console.log(lawfirm);
    if (membershipAccess != null && lawfirm != null) {
      lawfirm.forEach((law_firm_element: any) => {
        console.log("jjjjjjjjjjjjjj");
        if (law_firm_element.user_id === loginUser.id) {
          membershipAccess.forEach((membership_access_element: any) => {
            if (membership_access_element.law_firm_id === law_firm_element.id) {
              setUserMembership(membership_access_element);
            }
          });
        }
      });
    }
  }, [loginUser, lawfirm]);

  //Subscriptions
  //***************************************************/
  //User sub
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateUserSubscription>>(
      graphqlOperation(subscriptions.onUpdateUser)
    ).subscribe({
      next: ({ provider, value }) => {
        updateStateDataObject(value.data?.onUpdateUser, user, setUser);
        setLoginUser(value.data?.onUpdateUser);
      },
      error: (error) => console.warn(error),
    });
    return () => {
      sub.unsubscribe();
    };
  }, []);

  //Law sub
  useEffect(() => {
    const sub = API.graphql<GraphQLSubscription<OnUpdateLawFirmSubscription>>(
      graphqlOperation(subscriptions.onUpdateLawFirm)
    ).subscribe({
      next: ({ provider, value }) => {
        //updateStateDataArry(value.data?.onUpdateLawFirm, lawfirm, setLawfirm);
      },
      error: (error) => console.warn(error),
    });
    return () => {
      sub.unsubscribe();
    };
  }, []);

  //Call functions
  useEffect(() => {
    getUsers();
    getCaseFile();
    getCompany();
    getPickUprequest();
    getMembershipMain();
    getMembershipAccess();
  }, []);

  //Login access
  useEffect(() => {
    checkUser();
  }, [user]);

  //Login access
  useEffect(() => {
    if (loginUser) {
      console.log(loginUser);
    }
  }, [loginUser]);

  //Subscription effects
  useEffect(() => {
    // Subscribe to creation of request
    const subRequest = API.graphql<
      GraphQLSubscription<OnCreatePickUpRequestSubscription>
    >(graphqlOperation(subscriptions.onCreatePickUpRequest)).subscribe({
      next: (response) => {
        const newItem = response.value.data?.onCreatePickUpRequest;
        setPickUprequest((pickRequest: any) => [...pickRequest, newItem]);
      },
      error: (error) => console.warn(error),
    });

    // Subscribe to creation of casefile
    const subCaseFile = API.graphql<
      GraphQLSubscription<OnCreateCaseFileSubscription>
    >(graphqlOperation(subscriptions.onCreateCaseFile)).subscribe({
      next: (response) => {
        const newItem = response.value.data?.onCreateCaseFile;
        setCasefile((casefile: any) => [...casefile, newItem]);
      },
      error: (error) => console.warn(error),
    });

    return () => {
      subRequest.unsubscribe();
      subCaseFile.unsubscribe();
    };
  }, []);

  //Subscription membershipAccess
  useEffect(() => {
    // Subscribe to creation of request
    const subRequest = API.graphql<
      GraphQLSubscription<OnUpdateMembershipAccessSubscription>
    >(graphqlOperation(subscriptions.onUpdateMembershipAccess)).subscribe({
      next: (response) => {
        const newItem = response.value.data?.onUpdateMembershipAccess;
        console.log(newItem);
        setUserMembership(newItem);
      },
      error: (error) => console.warn(error),
    });

    return () => {
      subRequest.unsubscribe();
    };
  }, []);

  // Function to generate a signed URL for a given S3 object key
  const generateSignedUrl = (objectKey: any) => {
    return Storage.get(objectKey, { expires: 60 }) // Expires in 60 seconds (adjust as needed)
      .then((signedURL) => signedURL)
      .catch((err) => console.log("Error generating signed URL:", err));
  };

  useEffect(() => {
    Storage.list("")
      .then(({ results }) => {
        if (results) {
          console.log(results);
          const promises = results.map((result) => {
            return generateSignedUrl(result.key);
          });

          Promise.all(promises)
            .then((signedURLs) => {
              // Combine the original results with the corresponding signed URLs
              const filesWithSignedURLs = results.map((result, index) => ({
                ...result,
                signedURL: signedURLs[index],
              }));

              console.log("Files with Signed URLs:", filesWithSignedURLs);
              setFileRecord(filesWithSignedURLs);
            })
            .catch((err) => console.log("Error generating signed URLs:", err));
        }
      })
      .catch((err) => console.log("Error listing files:", err));
  }, []);

  //Get all users
  async function getUsers() {
    const getAllUsers = await API.graphql<GraphQLQuery<ListUsersQuery>>({
      query: queries.listUsers,
    });

    //Get all users
    console.log(getAllUsers.data?.listUsers?.items);
    setUser(getAllUsers.data?.listUsers?.items);
  }

  //
  //User sign in function
  async function checkUser() {
    try {
      if (true) {
        await Auth.currentAuthenticatedUser().then((userData) => {
          //Set user email

          console.log("yebo");
          setTempEmailAuth(userData?.attributes?.email);
          for (let i = 0; i < user.length; i++) {
            if (user[i].email === userData?.attributes?.email) {
              Toast.fire({
                icon: "success",
                title: "Account infomation varified! Welcome.",
              });

              setLoginUser(user[i]);

              //break;
            } else if (i === user.length - 1) {
              Toast.fire({
                icon: "warning",
                title: "User Account not activated",
              });
              //signOut();
            }
          }
        });
      } else {
      }
    } catch (error) {
      console.log("error signing in", error);
    }
  }

  //User logout
  async function signOut() {
    try {
      await Auth.signOut();
    } catch (error) {}
  }

  //Get all law case file
  async function getCaseFile() {
    const getAllFiles = await API.graphql<GraphQLQuery<ListCaseFilesQuery>>({
      query: queries.listCaseFiles,
    });

    //Get all users
    setCasefile(getAllFiles.data?.listCaseFiles?.items);
    sortByLatestCreated(casefile);
  }

  //Get all Main Membership
  async function getMembershipMain() {
    const getAllMemberships = await API.graphql<
      GraphQLQuery<ListMembershipsQuery>
    >({
      query: queries.listMemberships,
    });

    //Get all firms
    setMembershipmain(getAllMemberships.data?.listMemberships?.items);
    sortByLatestCreated(membershipMain);
  }

  //Get all Main MembershipAccess
  async function getMembershipAccess() {
    const getAllMemberships = await API.graphql<
      GraphQLQuery<ListMembershipAccessesQuery>
    >({
      query: queries.listMembershipAccesses,
    });

    //Get all firms
    setMembershipAccess(getAllMemberships.data?.listMembershipAccesses?.items);
    sortByLatestCreated(membershipAccess);
  }

  //Get member
  async function getCompany() {
    const getAllComapanys = await API.graphql<GraphQLQuery<ListLawFirmsQuery>>({
      query: queries.listLawFirms,
    });

    //Get all firms
    setLawfirm(getAllComapanys.data?.listLawFirms?.items);
    sortByLatestCreated(lawfirm);
  }

  //Get all request
  async function getPickUprequest() {
    const getAllPickUpRequest = await API.graphql<
      GraphQLQuery<ListPickUpRequestsQuery>
    >({
      query: queries.listPickUpRequests,
    });

    //Get all users
    setPickUprequest(getAllPickUpRequest.data?.listPickUpRequests?.items);

    sortByLatestCreated(pickRequest);
  }

  //Update state function
  function updateStateDataArry(newData: any, prevData: any, stateObject: any) {
    stateObject((prevData: any) => [...prevData, ...newData]);
  }

  function updateStateDataObject(
    newData: any,
    prevData: any,
    stateObject: any
  ) {
    stateObject((prevData: any) => ({
      ...prevData,
      ...newData,
    }));
  }

  function sortByLatestCreated(records: any) {
    return records.sort((a: any, b: any) => {
      // Assuming there is a 'created_at' property in each object
      const dateA: any = new Date(a.created_at);
      const dateB: any = new Date(b.created_at);

      // Sort in descending order (latest first)
      return dateB - dateA;
    });
  }

  return (
    <IonApp>
      <IonReactRouter>
        <Users.Provider value={{ user, setUser }}>
          <CaseFile.Provider value={{ casefile, setCasefile }}>
            <LawFirm.Provider value={{ lawfirm, setLawfirm }}>
              <PickUprequest.Provider value={{ pickRequest, setPickUprequest }}>
                <LoginUser.Provider value={{ loginUser, setLoginUser }}>
                  <FilesRecord.Provider value={{ fileRecord, setFileRecord }}>
                    <MembershipAccess.Provider
                      value={{ membershipAccess, setMembershipAccess }}
                    >
                      <MembershipMainData.Provider
                        value={{ membershipMain, setMembershipmain }}
                      >
                        <UserMembershipMainData.Provider
                          value={{ userMembership, setUserMembership }}
                        >
                          <AuthSetEmail.Provider
                            value={{ tempEmailAuth, setTempEmailAuth }}
                          >
                            <IonRouterOutlet>
                              <Route exact path="/home">
                                <Home />
                              </Route>
                              <Route exact path="/request">
                                <Request />
                              </Route>
                              <Route path="/upload">
                                <Upload />
                              </Route>
                              <Route path="/userrequest">
                                <UserRequest />
                              </Route>
                              <Route path="/files">
                                <Files />
                              </Route>
                              <Route path="/updateFile">
                                <UpdateFile />
                              </Route>
                              <Route path="/consultation">
                                <Consultation />
                              </Route>
                              <Route path="/membership">
                                <Membership />
                              </Route>
                              <Route path="/readFile">
                                <ReadFile />
                              </Route>
                              <Route path="/profile">
                                <Profile />
                              </Route>
                              <Route path="/policies">
                                <Policies />
                              </Route>
                              <Route path="/billing">
                                <Billing />
                              </Route>
                              <Route path="/update">
                                <Update />
                              </Route>
                              <Route exact path="/">
                                <Redirect to="/home" />
                              </Route>
                            </IonRouterOutlet>
                          </AuthSetEmail.Provider>

                          <Nav />
                          <Footer />
                        </UserMembershipMainData.Provider>
                      </MembershipMainData.Provider>
                    </MembershipAccess.Provider>
                  </FilesRecord.Provider>
                </LoginUser.Provider>
              </PickUprequest.Provider>
            </LawFirm.Provider>
          </CaseFile.Provider>
        </Users.Provider>
        <IonTabBar style={{ display: "none" }} slot="bottom"></IonTabBar>
      </IonReactRouter>
    </IonApp>
  );
}

export default withAuthenticator(App, {
  components: {
    SignIn: {
      Header: SignInHeader,
      Footer: SignInFooter,
    },
    SignUp: {
      Header: SignUpHeader,
      Footer: SignInFooter,
    },
    ResetPassword: {
      Header: PasswordResetHeader,
      Footer: SignInFooter,
    },
  },
});
