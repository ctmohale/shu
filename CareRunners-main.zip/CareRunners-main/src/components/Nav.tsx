/////////
import {
  IonButton,
  IonCol,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonModal,
  IonRadio,
  IonRadioGroup,
  IonRow,
  IonSelect,
  IonSelectOption,
} from "@ionic/react";
import { HiMenuAlt3, HiUsers } from "react-icons/hi";
import {
  AiFillCar,
  AiFillSetting,
  AiOutlineCar,
  AiOutlineLogin,
} from "react-icons/ai";
import { GoLaw } from "react-icons/go";
import { HiHome } from "react-icons/hi";
import { API, Auth } from "aws-amplify";

import React from "react";
import "./Nav.css";
import { FaCar, FaCarAlt } from "react-icons/fa";
import LoginUser from "../context/login";
import { useContext, useState, useRef, useEffect } from "react";

import {
  IonButtons,
  IonContent,
  IonHeader,
  IonMenu,
  IonMenuButton,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import { RiHomeLine } from "react-icons/ri";
import { BiLogOutCircle, BiUser } from "react-icons/bi";
import Users from "../context/users";
import { CgMenuRight } from "react-icons/cg";
import { CreatePickUpRequestInput, CreatePickUpRequestMutation } from "../API";
import PickUprequest from "../context/request";
import { graphqlOperation } from "aws-amplify";
import { GraphQLQuery } from "@aws-amplify/api";
import * as mutations from "../graphql/mutations";
import Swal from "sweetalert2";
import { OverlayEventDetail } from "@ionic/react/dist/types/components/react-component-lib/interfaces";
import { MdOutlinePolicy } from "react-icons/md";
import UserMembershipMainData from "../context/userMembership";

import { SubMenu } from "@szhsin/react-menu";
import { Menu, MenuItem, MenuButton } from "@szhsin/react-menu";
import "@szhsin/react-menu/dist/index.css";
import "@szhsin/react-menu/dist/transitions/slide.css";

function Nav() {
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  const { userMembership, setUserMembership }: any = useContext(
    UserMembershipMainData
  );

  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  useEffect(() => {
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDNNpZLzHIO3x8w-z36vTTCG-Fqa4v5dRE&libraries=places`;
    script.async = true;
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  async function signOut() {
    try {
      await Auth.signOut();
    } catch (error) {
      console.log("error signing out: ", error);
    }
  }

  return (
    <>
      <nav className="navbar navbar-expand-lg bg-body-tertiary">
        <div className="container-fluid">
          <IonButton shape="round" routerLink="/" fill="clear" color="medium">
            <h6>
              Care <img src="assets/logo.png" width="50" /> Runners
            </h6>
          </IonButton>
          <IonButton
            className="main-menu"
            id="desk"
            fill="clear"
            color="medium"
            shape="round"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <HiMenuAlt3 size="25" className="menu_icon" />
          </IonButton>

          {/* Mobile menue */}
          <Menu
            menuButton={
              <MenuButton className="main-menu" color="medium" id="mobile_s">
                <CgMenuRight size="28" />
              </MenuButton>
            }
          >
            <div id="navbarSupportedContent">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <br />

                {loginUser.email !== undefined &&
                  userMembership.access_type !== undefined && (
                    <>
                      <li className="nav-item">
                        <IonButton
                          routerLink="/"
                          shape="round"
                          color="medium"
                          fill="clear"
                        >
                          <RiHomeLine size="25" /> &#160; Home
                        </IonButton>
                      </li>
                      <li className="nav-item">
                        <IonButton
                          disabled
                          shape="round"
                          routerLink="/consultation"
                          color="medium"
                          fill="clear"
                        >
                          <GoLaw size="25" /> &#160; Consultation
                        </IonButton>
                      </li>
                      <li className="nav-item">
                        <IonButton
                          routerLink="/userrequest"
                          shape="round"
                          color="medium"
                          fill="clear"
                        >
                          <AiOutlineCar size="25" /> &#160; Request Pick-Up
                        </IonButton>
                      </li>
                      <li className="nav-item">
                        <IonButton
                          shape="round"
                          routerLink="/policies"
                          color="medium"
                          fill="clear"
                        >
                          <MdOutlinePolicy size="25" /> &#160; POLICIES
                        </IonButton>
                      </li>
                    </>
                  )}
              </ul>
              <form className="d-flex" role="search">
                {true ? (
                  <>
                    <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                      {loginUser.email !== undefined &&
                        userMembership.access_type !== undefined && (
                          <li className="nav-item">
                            <IonButton
                              routerLink="/Profile"
                              fill="clear"
                              shape="round"
                              color="medium"
                            >
                              <BiUser size="25" /> &#160;
                              {loginUser.name.substring(0, 1) +
                                " " +
                                loginUser.surname}
                            </IonButton>
                          </li>
                        )}
                      <li className="nav-item">
                        <IonButton
                          shape="round"
                          onClick={() => signOut()}
                          fill="clear"
                          color="medium"
                        >
                          <BiLogOutCircle size="25" /> &#160; Sign Out
                        </IonButton>
                      </li>
                    </ul>
                  </>
                ) : (
                  <IonButton shape="round" fill="clear" color="medium">
                    <AiOutlineLogin size="25" /> &#160; Sign In
                  </IonButton>
                )}
              </form>
            </div>
          </Menu>

          <div
            className="collapse navbar-collapse p-2"
            id="navbarSupportedContent"
          >
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <br />

              {loginUser.email !== undefined &&
                userMembership.access_type !== undefined && (
                  <>
                    <li className="nav-item">
                      <IonButton
                        routerLink="/"
                        shape="round"
                        color="medium"
                        fill="clear"
                      >
                        <RiHomeLine size="25" /> &#160; Home
                      </IonButton>
                    </li>
                    <li className="nav-item">
                      <IonButton
                        shape="round"
                        routerLink="/consultation"
                        color="medium"
                        fill="clear"
                      >
                        <GoLaw size="25" /> &#160; Consultation
                      </IonButton>
                    </li>
                    <li className="nav-item">
                      <IonButton
                        routerLink="/userrequest"
                        shape="round"
                        color="medium"
                        fill="clear"
                      >
                        <AiOutlineCar size="25" /> &#160; Request Pick-Up
                      </IonButton>
                    </li>
                    <li className="nav-item">
                      <IonButton
                        shape="round"
                        routerLink="/policies"
                        color="medium"
                        fill="clear"
                      >
                        <MdOutlinePolicy size="25" /> &#160; POLICIES
                      </IonButton>
                    </li>
                  </>
                )}
            </ul>
            <form className="d-flex" role="search">
              {true ? (
                <>
                  <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                    {loginUser.email !== undefined &&
                      userMembership.access_type !== undefined && (
                        <li className="nav-item">
                          <IonButton
                            routerLink="/Profile"
                            fill="clear"
                            shape="round"
                            color="medium"
                          >
                            <BiUser size="25" /> &#160;
                            {loginUser.name.substring(0, 1) +
                              " " +
                              loginUser.surname}
                          </IonButton>
                        </li>
                      )}
                    <li className="nav-item">
                      <IonButton
                        shape="round"
                        onClick={() => signOut()}
                        fill="clear"
                        color="medium"
                      >
                        <BiLogOutCircle size="25" /> &#160; Sign Out
                      </IonButton>
                    </li>
                  </ul>
                </>
              ) : (
                <IonButton shape="round" fill="clear" color="medium">
                  <AiOutlineLogin size="25" /> &#160; Sign In
                </IonButton>
              )}
            </form>
          </div>
        </div>
      </nav>
    </>
  );
}
export default Nav;
