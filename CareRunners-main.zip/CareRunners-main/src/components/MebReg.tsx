import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonPage,
  IonRow,
  IonTitle,
} from "@ionic/react";
import "../pages/Home.css";
import Nav from "../components/Nav";
import { AiOutlineUser } from "react-icons/ai";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { GoLaw } from "react-icons/go";
import { useContext, useEffect, useState } from "react";
import Users from "../context/users";
import LoginUser from "../context/login";
import LawFirm from "../context/lawfirm";
import {
  CreateLawFirmInput,
  CreateLawFirmMutation,
  CreateMembershipAccessInput,
  CreateMembershipAccessMutation,
  CreateUserInput,
  CreateUserMutation,
  UpdateLawFirmInput,
  UpdateLawFirmMutation,
  UpdateUserInput,
  UpdateUserMutation,
} from "../API";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { GraphQLQuery } from "@aws-amplify/api";
import Swal from "sweetalert2";
import { HashLoader } from "react-spinners";
import AuthSetEmail from "../context/authEmail";
import { BsPatchCheckFill } from "react-icons/bs";
import MembershipMainData from "../context/membershipMain";

const MebReg: React.FC = () => {
  //Global var
  const { user, setUser }: any = useContext(Users);
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);
  const { tempEmailAuth, setTempEmailAuth }: any = useContext(AuthSetEmail);

  //Company var
  const [comapany_id, set_comapany_id]: any = useState("");
  const [temp_m_id, set_temp_m_id]: any = useState("");
  const [isLoading, setIsloading]: any = useState(true);
  const { membershipMain }: any = useContext(MembershipMainData);
  //Sweet Alert Toast
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  useEffect(() => {
    if (membershipMain && loginUser.id !== undefined) {
      lawfirm.forEach((element: any) => {
        if (element.user_id === loginUser.id) {
          set_temp_m_id(element.id);
        }
      });
    }
  }, [membershipMain]);

  useEffect(() => {
    if (lawfirm && loginUser.id !== undefined) {
      lawfirm.forEach((element: any) => {
        if (element.user_id === loginUser.id) {
          set_comapany_id(element.id);
        }
      });
    }
  }, [lawfirm]);

  useEffect(() => {
    if (lawfirm && loginUser.id !== undefined) {
      lawfirm.forEach((element: any) => {
        if (element.user_id === loginUser.id) {
          set_comapany_id(element.id);
        }
      });
    }
  }, [lawfirm]);

  useEffect(() => {
    if (loginUser.id) {
      setIsloading(false);
    }
  }, [loginUser]);

  //Add Law
  async function addMembership(id: any, price: any, access: any) {
    membershipMain.forEach((element: any) => {
      if (access === element.membership_type) {
        set_temp_m_id(element.id);
      }
    });
    //Comapany details
    const membershipDetails: CreateMembershipAccessInput = {
      access_type: access,
      membership_price: price,
      law_firm_id: comapany_id,
      membership_id: temp_m_id,
    };

    //Company
    const addNewMembership = await API.graphql<
      GraphQLQuery<CreateMembershipAccessMutation>
    >({
      query: mutations.createMembershipAccess,
      variables: { input: membershipDetails },
    });

    if (addNewMembership) {
      Toast.fire({
        icon: "success",
        title: "Membership added successfully!.",
      });

      setTimeout(function () {
        window.location.href = "/home";
      }, 2000);
    }
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />

        {isLoading === false && loginUser.email !== undefined ? (
          <>
            <div className="main-title-reg">
              <IonTitle className="ion_t" color="medium">
                Select A Membership
              </IonTitle>
              <IonItem>
                <IonLabel></IonLabel>
              </IonItem>
            </div>
            <IonGrid>
              <IonRow className="main_row">
                {/* File upload section */}

                <IonCol>
                  <IonCard className="main_card p-0 m-0" id="m_section">
                    <div className="row m-0 p-0 m-0">
                      <div className="col-sm-2 membership">
                        <div className="card-body">
                          <h5 className="card-title text-secondary p-2">
                            Bronze Package
                          </h5>

                          <p className="card-text text-secondary">
                            RAM: 2 GB | Support & Maintenance
                          </p>
                          <p>
                            <b>R350.00</b>
                          </p>
                          <span className="text-secondary">
                            <BsPatchCheckFill size="20" />
                          </span>
                          <br />
                          <IonButton
                            onClick={() =>
                              addMembership("id", "350.00", " Bronze Package")
                            }
                            fill="outline"
                            shape="round"
                            color="success"
                            className="ion-margin"
                          >
                            Activate
                          </IonButton>
                        </div>
                      </div>
                      <div className="col-sm-2 membership">
                        <div className="card-body">
                          <h5 className="card-title text-secondary p-2">
                            Silver Package
                          </h5>
                          <p className="card-text text-secondary">
                            RAM: 4GB | Support & Maintenance
                          </p>
                          <p>
                            <b>R550.00</b>
                          </p>
                          <span className="text-secondary">
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                          </span>
                          <br />
                          <IonButton
                            onClick={() =>
                              addMembership("id", "550.00", "Silver Package")
                            }
                            fill="outline"
                            shape="round"
                            color="success"
                            className="ion-margin"
                          >
                            Activate
                          </IonButton>
                        </div>
                      </div>
                      <div className="col-sm-2 membership">
                        <div className="card-body">
                          <h5 className="card-title text-secondary p-2">
                            Gold Package
                          </h5>
                          <p className="card-text text-secondary">
                            RAM: 6GB | Support & Maintenance
                          </p>
                          <p>
                            <b>R650.00</b>
                          </p>
                          <span className="text-secondary">
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                          </span>
                          <br />
                          <IonButton
                            onClick={() =>
                              addMembership("id", "650.00", "Gold Package")
                            }
                            fill="outline"
                            shape="round"
                            color="success"
                            className="ion-margin"
                          >
                            Activate
                          </IonButton>
                        </div>
                      </div>
                      <div className="col-sm-2 membership">
                        <div className="card-body">
                          <h5 className="card-title text-secondary p-2">
                            Platinum Package
                          </h5>
                          <p className="card-text text-secondary">
                            RAM: 4GB | Support & Maintenance
                          </p>
                          <p>
                            <b>R750.00</b>
                          </p>
                          <span>
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                          </span>
                          <br />
                          <IonButton
                            onClick={() =>
                              addMembership("id", "750.00", "Platinum Package")
                            }
                            fill="outline"
                            shape="round"
                            color="success"
                            className="ion-margin"
                          >
                            Activate
                          </IonButton>
                        </div>
                      </div>
                      <div className="col-sm-2 membership">
                        <div className="card-body">
                          <h5 className="card-title text-secondary p-2">
                            Palladium Package
                          </h5>
                          <p className="card-text text-secondary">
                            RAM: 6GB | Support & Maintenance
                          </p>
                          <p>
                            <b>R1 200.00</b>
                          </p>
                          <span>
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                            <BsPatchCheckFill size="20" />
                          </span>
                          <br />
                          <IonButton
                            onClick={() =>
                              addMembership(
                                "id",
                                "1 200.00",
                                "Palladium Package"
                              )
                            }
                            fill="outline"
                            shape="round"
                            color="success"
                            className="ion-margin"
                          >
                            Activate
                          </IonButton>
                        </div>
                      </div>
                    </div>

                    <br />
                  </IonCard>
                </IonCol>
              </IonRow>
              <br />
              <br />
              <br />
            </IonGrid>
          </>
        ) : (
          <>
            <HashLoader color="#36d7b7" />
          </>
        )}
      </IonContent>
    </IonPage>
  );
};

export default MebReg;
