import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardSubtitle,
  IonCardTitle,
  IonCol,
  IonContent,
  IonGrid,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonPage,
  IonRow,
  IonTitle,
} from "@ionic/react";
import "../pages/Home.css";
import Nav from "../components/Nav";
import { AiOutlineUser } from "react-icons/ai";
import { AiOutlineCloudUpload } from "react-icons/ai";
import { GoLaw } from "react-icons/go";
import { useContext, useEffect, useState } from "react";
import Users from "../context/users";
import LoginUser from "../context/login";
import LawFirm from "../context/lawfirm";
import {
  CreateLawFirmInput,
  CreateLawFirmMutation,
  CreateUserInput,
  CreateUserMutation,
  UpdateLawFirmInput,
  UpdateLawFirmMutation,
  UpdateUserInput,
  UpdateUserMutation,
} from "../API";
import { API } from "aws-amplify";
import * as mutations from "../graphql/mutations";
import { GraphQLQuery } from "@aws-amplify/api";
import Swal from "sweetalert2";
import { HashLoader } from "react-spinners";
import AuthSetEmail from "../context/authEmail";

const FirmReg: React.FC = () => {
  //Global var
  const { user, setUser }: any = useContext(Users);
  const { loginUser, setLoginUser }: any = useContext(LoginUser);
  const { lawfirm, setLawfirm }: any = useContext(LawFirm);
  const { tempEmailAuth, setTempEmailAuth }: any = useContext(AuthSetEmail);

  //User profile
  const [name, setName]: any = useState("");
  const [surname, setSurname]: any = useState("");
  const [email, setEmail]: any = useState("");
  const [cell, setCell]: any = useState("");

  //Company var
  const [comapany_name, set_comapany_name]: any = useState();
  const [comapany_cell_no, set_comapany_cell_no]: any = useState();
  const [comapany_email, set_comapany_email]: any = useState();
  const [comapany_reg, set_comapany_reg]: any = useState();
  const [comapany_addess, set_comapany_address]: any = useState();
  const [comapany_postal_Code, set_comapany_postal_Code]: any = useState();
  const [comapany_id, set_comapany_id]: any = useState("");
  const [isLoading, setIsloading]: any = useState(true);

  //Sweet Alert Toast
  const Toast = Swal.mixin({
    toast: true,
    position: "top-end",
    showConfirmButton: false,
    timer: 3000,
    timerProgressBar: true,
    didOpen: (toast) => {
      toast.addEventListener("mouseenter", Swal.stopTimer);
      toast.addEventListener("mouseleave", Swal.resumeTimer);
    },
  });

  useEffect(() => {
    console.log(tempEmailAuth);
  }, [tempEmailAuth]);

  //Set user
  useEffect(() => {
    if (loginUser) {
      setName(loginUser.name);
      setSurname(loginUser.surname);
      setCell(loginUser.cell_no);
      setEmail(loginUser.email);
    }
  }, [loginUser]);

  useEffect(() => {
    if (tempEmailAuth) {
      setIsloading(false);
    }
  }, [tempEmailAuth]);

  //Set comapnay
  useEffect(() => {
    if (lawfirm && loginUser) {
      lawfirm.forEach((firm_element: any) => {
        if (firm_element.user_id === loginUser.id) {
          console.log(lawfirm);
          set_comapany_name(firm_element.company_name);
          set_comapany_address(firm_element.address);
          set_comapany_cell_no(firm_element.cell_no);
          set_comapany_email(firm_element.comapany_email);
          set_comapany_reg(firm_element.comapany_reg);
          set_comapany_postal_Code(firm_element.postal_code);
          set_comapany_id(firm_element.id);
        }
      });
    }
  }, [lawfirm, loginUser]);

  //update profile function
  async function addlawFirm() {
    if (
      name === "" ||
      surname === "" ||
      cell === "" ||
      comapany_name === undefined ||
      comapany_postal_Code === undefined ||
      comapany_email === undefined ||
      comapany_cell_no === undefined ||
      comapany_addess === undefined
    ) {
      Toast.fire({
        icon: "warning",
        title: "Please complete all input fileds!.",
      });
      return;
    }

    let userID: any = "";
    //User info
    const userDetails: CreateUserInput = {
      name: name,
      surname: surname,
      cell_no: cell,
      email: tempEmailAuth,
      access: "active",
    };

    //User
    const addUserData = await API.graphql<GraphQLQuery<CreateUserMutation>>({
      query: mutations.createUser,
      variables: { input: userDetails },
    });

    if (addUserData) {
      console.log(addUserData);

      //Law Firm
      addLawFirmFunction(addUserData.data?.createUser?.id);

      Toast.fire({
        icon: "success",
        title: "Law firm profile created successfully!!.",
      });

      setTimeout(function () {
        window.location.href = "/home";
      }, 2000);
    }
  }

  //Add Law
  async function addLawFirmFunction(id: any) {
    //Comapany details
    const companayDetails: CreateLawFirmInput = {
      company_name: comapany_name,
      company_registartion: comapany_reg,
      postal_code: comapany_postal_Code,
      company_email: comapany_email,
      address: comapany_addess,
      cell_no: comapany_cell_no,
      user_id: id,
    };

    //Company
    const addCompanay = await API.graphql<GraphQLQuery<CreateLawFirmMutation>>({
      query: mutations.createLawFirm,
      variables: { input: companayDetails },
    });
  }

  return (
    <IonPage>
      <IonContent fullscreen>
        {/* Navigation section */}
        <Nav />

        {isLoading === false && loginUser.email === undefined ? (
          <>
            {" "}
            <div className="main-title-reg">
              <IonTitle className="ion_t" color="medium">
                Law firm registartion
              </IonTitle>
              <IonItem>
                <IonLabel></IonLabel>
              </IonItem>
            </div>
            <IonGrid>
              <IonRow className="main_row">
                {/* File upload section */}

                <IonCol>
                  <IonCard className="main_card" style={{ padding: "5%" }}>
                    <IonTitle
                      className="title_mobile"
                      id="u_profile"
                      color="medium"
                      style={{ textAlign: "left" }}
                    >
                      <AiOutlineUser size="25" /> User profile
                    </IonTitle>
                    <br />
                    <br />
                    <IonItem>
                      <IonInput
                        color="medium"
                        label="*Name"
                        labelPlacement="floating"
                        onIonInput={(e: any) => setName(e.detail.value)}
                        placeholder="Enter text"
                      ></IonInput>
                    </IonItem>
                    <IonItem>
                      <IonInput
                        color="medium"
                        label="*Last-name"
                        onIonInput={(e: any) => setSurname(e.detail.value)}
                        labelPlacement="floating"
                        placeholder="Enter text"
                      ></IonInput>
                    </IonItem>
                    <IonItem>
                      <IonInput
                        color="medium"
                        label="*Cell phone number"
                        type="number"
                        onIonInput={(e: any) => setCell(e.detail.value)}
                        labelPlacement="floating"
                        placeholder="Enter text"
                      ></IonInput>
                    </IonItem>
                    <IonItem>
                      <IonInput
                        disabled
                        label="*Email"
                        type="email"
                        onIonInput={(e: any) => setEmail(e.detail.value)}
                        labelPlacement="floating"
                        value={tempEmailAuth}
                        placeholder="Enter text"
                      ></IonInput>
                    </IonItem>
                    <IonItem>
                      <IonInput
                        disabled
                        color="medium"
                        type="password"
                        value="00000000"
                        label="*Password"
                        labelPlacement="floating"
                        placeholder="Enter text"
                      ></IonInput>
                    </IonItem>
                  </IonCard>
                </IonCol>

                <IonCol>
                  <IonTitle
                    className="title_mobile"
                    id="c_profile"
                    color="medium"
                    style={{ textAlign: "left" }}
                  >
                    <GoLaw /> Compnay profile
                  </IonTitle>
                  <hr />
                  <IonItem>
                    <IonInput
                      label="*Company name"
                      onIonInput={(e: any) => set_comapany_name(e.detail.value)}
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                  <IonItem>
                    <IonInput
                      label="Company registration no"
                      onIonInput={(e: any) => set_comapany_reg(e.detail.value)}
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>

                  <IonItem>
                    <IonInput
                      color="medium"
                      label="*Company email"
                      type="email"
                      onIonInput={(e: any) =>
                        set_comapany_email(e.detail.value)
                      }
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>
                  <IonItem>
                    <IonInput
                      color="medium"
                      label="*Address"
                      onIonInput={(e: any) =>
                        set_comapany_address(e.detail.value)
                      }
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>

                  <IonItem>
                    <IonInput
                      color="medium"
                      label="*Postal code"
                      type="number"
                      onIonInput={(e: any) =>
                        set_comapany_postal_Code(e.detail.value)
                      }
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>

                  <IonItem>
                    <IonInput
                      label="*Company cell-phone:"
                      type="number"
                      color="medium"
                      onIonInput={(e: any) =>
                        set_comapany_cell_no(e.detail.value)
                      }
                      labelPlacement="floating"
                      placeholder="Enter text"
                    ></IonInput>
                  </IonItem>

                  <IonButton
                    shape="round"
                    fill="outline"
                    color="medium"
                    className="btn_up btn-request-update ion-margin"
                    onClick={() => addlawFirm()}
                  >
                    <AiOutlineUser size="20" /> &nbsp; Submit Information
                  </IonButton>
                </IonCol>
              </IonRow>
              <br />
              <br />
              <br />
            </IonGrid>
          </>
        ) : (
          <>
            <HashLoader color="#36d7b7" />
          </>
        )}
      </IonContent>
    </IonPage>
  );
};

export default FirmReg;
