import React from 'react'

function RequestUpdate() {
  return (
    <div>RequestUpdate</div>
  )
}

export default RequestUpdate